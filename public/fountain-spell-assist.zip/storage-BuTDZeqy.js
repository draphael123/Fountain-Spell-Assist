const STORAGE_KEYS = {
  GLOBAL_SETTINGS: "globalSettings",
  SITE_SETTINGS_PREFIX: "site:",
  CUSTOM_DICTIONARY: "customDictionary",
  STATISTICS: "statistics"
};
const DEFAULT_STATISTICS = {
  wordsChecked: 0,
  misspellingsFound: 0,
  correctionsMade: 0,
  wordsAdded: 0,
  lastReset: Date.now()
};
const DEFAULT_GLOBAL_SETTINGS = {
  enabled: true,
  showUnderlines: true,
  language: "en-US",
  disabledPatterns: [],
  autoCorrect: false,
  grammarCheck: false
};
const DEFAULT_SITE_SETTINGS = {
  enabled: true
};
async function getGlobalSettings() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.GLOBAL_SETTINGS);
  return { ...DEFAULT_GLOBAL_SETTINGS, ...result[STORAGE_KEYS.GLOBAL_SETTINGS] };
}
async function setGlobalSettings(settings) {
  const current = await getGlobalSettings();
  const updated = { ...current, ...settings };
  await chrome.storage.sync.set({ [STORAGE_KEYS.GLOBAL_SETTINGS]: updated });
  return updated;
}
async function getSiteSettings(hostname) {
  const key = `${STORAGE_KEYS.SITE_SETTINGS_PREFIX}${hostname}`;
  const result = await chrome.storage.sync.get(key);
  return { ...DEFAULT_SITE_SETTINGS, ...result[key] };
}
async function setSiteSettings(hostname, settings) {
  const key = `${STORAGE_KEYS.SITE_SETTINGS_PREFIX}${hostname}`;
  const current = await getSiteSettings(hostname);
  const updated = { ...current, ...settings };
  await chrome.storage.sync.set({ [key]: updated });
  return updated;
}
async function getCustomDictionary() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.CUSTOM_DICTIONARY);
  return result[STORAGE_KEYS.CUSTOM_DICTIONARY] || [];
}
async function addToDictionary(word) {
  const normalizedWord = word.toLowerCase().trim();
  if (!normalizedWord) return false;
  const entries = await getCustomDictionary();
  if (entries.some((e) => e.word.toLowerCase() === normalizedWord)) {
    return false;
  }
  const newEntry = {
    word: normalizedWord,
    addedAt: Date.now()
  };
  entries.push(newEntry);
  await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: entries });
  return true;
}
async function removeFromDictionary(word) {
  const normalizedWord = word.toLowerCase().trim();
  const entries = await getCustomDictionary();
  const filtered = entries.filter((e) => e.word.toLowerCase() !== normalizedWord);
  if (filtered.length === entries.length) {
    return false;
  }
  await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: filtered });
  return true;
}
async function importDictionary(words) {
  const entries = await getCustomDictionary();
  const existingWords = new Set(entries.map((e) => e.word.toLowerCase()));
  let addedCount = 0;
  const now = Date.now();
  for (const word of words) {
    const normalized = word.toLowerCase().trim();
    if (normalized && !existingWords.has(normalized)) {
      entries.push({ word: normalized, addedAt: now });
      existingWords.add(normalized);
      addedCount++;
    }
  }
  if (addedCount > 0) {
    await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: entries });
  }
  return addedCount;
}
async function exportDictionary() {
  const entries = await getCustomDictionary();
  return entries.map((e) => e.word);
}
async function getStatistics() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.STATISTICS);
  return { ...DEFAULT_STATISTICS, ...result[STORAGE_KEYS.STATISTICS] };
}
async function updateStatistics(updates) {
  const current = await getStatistics();
  const updated = { ...current, ...updates };
  await chrome.storage.sync.set({ [STORAGE_KEYS.STATISTICS]: updated });
  return updated;
}
const storage = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addToDictionary,
  exportDictionary,
  getCustomDictionary,
  getGlobalSettings,
  getSiteSettings,
  getStatistics,
  importDictionary,
  removeFromDictionary,
  setGlobalSettings,
  setSiteSettings,
  updateStatistics
}, Symbol.toStringTag, { value: "Module" }));
export {
  DEFAULT_STATISTICS as D,
  STORAGE_KEYS as S,
  getCustomDictionary as a,
  addToDictionary as b,
  getSiteSettings as c,
  setGlobalSettings as d,
  exportDictionary as e,
  getGlobalSettings as f,
  getStatistics as g,
  DEFAULT_GLOBAL_SETTINGS as h,
  importDictionary as i,
  DEFAULT_SITE_SETTINGS as j,
  storage as k,
  removeFromDictionary as r,
  setSiteSettings as s,
  updateStatistics as u
};
//# sourceMappingURL=storage-BuTDZeqy.js.map
