import { r as reactExports, j as jsxRuntimeExports, c as createRoot, R as React } from "./client-D2JabqeI.js";
import { a as setGlobalSettings, r as removeFromDictionary, e as exportDictionary, i as importDictionary, f as getDictionary, h as resetStatistics, c as getStatistics, b as getGlobalSettings } from "../content.js";
function Options() {
  const [loading, setLoading] = reactExports.useState(true);
  const [settings, setSettings] = reactExports.useState(null);
  const [dictionary, setDictionary] = reactExports.useState([]);
  const [statistics, setStatistics] = reactExports.useState(null);
  const [newPattern, setNewPattern] = reactExports.useState("");
  const [dictionarySearch, setDictionarySearch] = reactExports.useState("");
  const [selectedWords, setSelectedWords] = reactExports.useState(/* @__PURE__ */ new Set());
  const [modal, setModal] = reactExports.useState(null);
  const [importText, setImportText] = reactExports.useState("");
  const [exportText, setExportText] = reactExports.useState("");
  const [settingsText, setSettingsText] = reactExports.useState("");
  const [toast, setToast] = reactExports.useState(null);
  reactExports.useEffect(() => {
    async function load() {
      try {
        const [globalSettings, dict, stats] = await Promise.all([
          getGlobalSettings(),
          getDictionary(),
          getStatistics().catch(() => null)
        ]);
        setSettings(globalSettings);
        setDictionary(dict);
        setStatistics(stats);
      } catch (error) {
        console.error("Failed to load:", error);
        showToast("Failed to load settings", "error");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);
  const showToast = reactExports.useCallback((message, type) => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3e3);
  }, []);
  const updateSettings = reactExports.useCallback(async (updates) => {
    if (!settings) return;
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    try {
      await setGlobalSettings(updates);
    } catch (error) {
      console.error("Failed to update settings:", error);
      setSettings(settings);
      showToast("Failed to save settings", "error");
    }
  }, [settings, showToast]);
  const addPattern = reactExports.useCallback(async () => {
    if (!settings || !newPattern.trim()) return;
    const pattern = newPattern.trim();
    if (settings.disabledPatterns.includes(pattern)) {
      showToast("Pattern already exists", "error");
      return;
    }
    const newPatterns = [...settings.disabledPatterns, pattern];
    await updateSettings({ disabledPatterns: newPatterns });
    setNewPattern("");
    showToast("Pattern added", "success");
  }, [settings, newPattern, updateSettings, showToast]);
  const removePattern = reactExports.useCallback(async (pattern) => {
    if (!settings) return;
    const newPatterns = settings.disabledPatterns.filter((p) => p !== pattern);
    await updateSettings({ disabledPatterns: newPatterns });
    showToast("Pattern removed", "success");
  }, [settings, updateSettings, showToast]);
  const removeWord = reactExports.useCallback(async (word) => {
    try {
      await removeFromDictionary(word);
      setDictionary((prev) => prev.filter((e) => e.word !== word));
      showToast("Word removed", "success");
    } catch (error) {
      console.error("Failed to remove word:", error);
      showToast("Failed to remove word", "error");
    }
  }, [showToast]);
  const openImport = reactExports.useCallback(() => {
    setImportText("");
    setModal("import");
  }, []);
  const openExport = reactExports.useCallback(async () => {
    try {
      const words = await exportDictionary();
      setExportText(words.join("\n"));
      setModal("export");
    } catch (error) {
      console.error("Failed to export:", error);
      showToast("Failed to export dictionary", "error");
    }
  }, [showToast]);
  const handleImport = reactExports.useCallback(async () => {
    const words = importText.split("\n").map((w) => w.trim()).filter((w) => w.length > 0);
    if (words.length === 0) {
      showToast("No words to import", "error");
      return;
    }
    try {
      const added = await importDictionary(words);
      const dict = await getDictionary();
      setDictionary(dict);
      setModal(null);
      showToast(`Imported ${added} new words`, "success");
    } catch (error) {
      console.error("Failed to import:", error);
      showToast("Failed to import dictionary", "error");
    }
  }, [importText, showToast]);
  const copyExport = reactExports.useCallback(() => {
    navigator.clipboard.writeText(exportText);
    showToast("Copied to clipboard", "success");
  }, [exportText, showToast]);
  const exportAllSettings = reactExports.useCallback(async () => {
    try {
      const allSettings = {
        globalSettings: settings,
        dictionary: dictionary.map((e) => e.word),
        statistics,
        exportDate: (/* @__PURE__ */ new Date()).toISOString(),
        version: "1.0.0"
      };
      const json = JSON.stringify(allSettings, null, 2);
      setSettingsText(json);
      setModal("export-settings");
    } catch (error) {
      console.error("Failed to export settings:", error);
      showToast("Failed to export settings", "error");
    }
  }, [settings, dictionary, statistics, showToast]);
  const openImportSettings = reactExports.useCallback(() => {
    setSettingsText("");
    setModal("import-settings");
  }, []);
  reactExports.useCallback(async () => {
    try {
      const imported = JSON.parse(settingsText);
      if (imported.globalSettings) {
        await setGlobalSettings(imported.globalSettings);
        setSettings(imported.globalSettings);
      }
      if (imported.dictionary && Array.isArray(imported.dictionary)) {
        const added = await importDictionary(imported.dictionary);
        const dict = await getDictionary();
        setDictionary(dict);
        showToast(`Imported ${added} words`, "success");
      }
      setModal(null);
      showToast("Settings imported successfully", "success");
    } catch (error) {
      console.error("Failed to import settings:", error);
      showToast("Invalid settings file", "error");
    }
  }, [settingsText, showToast]);
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "loading", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "loading-spinner" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "options-container", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "options-header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "options-logo", children: "🖋" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "options-title", children: "Fountain Spell Assist" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "options-subtitle", children: "Settings & Configuration" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "General" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-label", children: "Enable Spell Checking" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-description", children: "Master switch for all spell checking functionality" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: `toggle-switch ${(settings == null ? void 0 : settings.enabled) ? "active" : ""}`,
              onClick: () => updateSettings({ enabled: !(settings == null ? void 0 : settings.enabled) }),
              "aria-label": "Toggle spell checking"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-label", children: "Show Underlines" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-description", children: "Display red underlines under misspelled words" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: `toggle-switch ${(settings == null ? void 0 : settings.showUnderlines) ? "active" : ""}`,
              onClick: () => updateSettings({ showUnderlines: !(settings == null ? void 0 : settings.showUnderlines) }),
              "aria-label": "Toggle underlines"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-label", children: "Language" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-description", children: "Dictionary language for spell checking" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "select-wrapper", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "select",
            {
              value: (settings == null ? void 0 : settings.language) || "en-US",
              onChange: (e) => updateSettings({ language: e.target.value }),
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "en-US", children: "English (US)" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "en-GB", children: "English (UK)" })
              ]
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-label", children: "Auto-Correct" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-description", children: "Automatically correct misspellings when you type space or enter" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: `toggle-switch ${(settings == null ? void 0 : settings.autoCorrect) ? "active" : ""}`,
              onClick: () => updateSettings({ autoCorrect: !(settings == null ? void 0 : settings.autoCorrect) }),
              "aria-label": "Toggle auto-correct"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "setting-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-label", children: "Grammar Checking" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "setting-description", children: "Detect common grammar mistakes (your/you're, its/it's, etc.)" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: `toggle-switch ${(settings == null ? void 0 : settings.grammarCheck) ? "active" : ""}`,
              onClick: () => updateSettings({ grammarCheck: !(settings == null ? void 0 : settings.grammarCheck) }),
              "aria-label": "Toggle grammar checking"
            }
          )
        ] })
      ] })
    ] }),
    statistics && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "Statistics" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "statistics-dashboard", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-label", children: "Words Checked:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-value", children: statistics.wordsChecked.toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-label", children: "Misspellings Found:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-value", children: statistics.misspellingsFound.toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-label", children: "Corrections Made:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-value", children: statistics.correctionsMade.toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-label", children: "Words Added to Dictionary:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "stat-value", children: statistics.wordsAdded.toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-actions", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "btn btn-secondary",
            onClick: async () => {
              if (confirm("Reset all statistics?")) {
                await resetStatistics();
                const stats = await getStatistics();
                setStatistics(stats);
                showToast("Statistics reset", "success");
              }
            },
            children: "Reset Statistics"
          }
        ) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "Custom Dictionary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "dictionary-header", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "dictionary-count", children: [
            dictionary.length,
            " word",
            dictionary.length !== 1 ? "s" : ""
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "dictionary-actions", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: openImport, children: "Import Words" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: openExport, children: "Export Words" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: exportAllSettings, children: "Export All Settings" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: openImportSettings, children: "Import Settings" }),
            selectedWords.size > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                className: "btn btn-danger",
                onClick: async () => {
                  if (confirm(`Delete ${selectedWords.size} selected word(s)?`)) {
                    for (const word of selectedWords) {
                      await removeWord(word);
                    }
                    setSelectedWords(/* @__PURE__ */ new Set());
                    const dict = await getDictionary();
                    setDictionary(dict);
                    showToast(`Deleted ${selectedWords.size} word(s)`, "success");
                  }
                },
                children: [
                  "Delete Selected (",
                  selectedWords.size,
                  ")"
                ]
              }
            )
          ] })
        ] }),
        dictionary.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "dictionary-search", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            className: "pattern-input",
            placeholder: "Search dictionary...",
            value: dictionarySearch,
            onChange: (e) => setDictionarySearch(e.target.value)
          }
        ) }),
        dictionary.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "dictionary-empty", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No custom words added yet." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: 'Words you add via "Add to Dictionary" will appear here.' })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "dictionary-list", children: dictionary.filter(
          (entry) => !dictionarySearch || entry.word.toLowerCase().includes(dictionarySearch.toLowerCase())
        ).map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "dictionary-item", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "dictionary-checkbox", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "checkbox",
                checked: selectedWords.has(entry.word),
                onChange: (e) => {
                  const newSelected = new Set(selectedWords);
                  if (e.target.checked) {
                    newSelected.add(entry.word);
                  } else {
                    newSelected.delete(entry.word);
                  }
                  setSelectedWords(newSelected);
                }
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "dictionary-word", children: entry.word })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn-icon",
              onClick: () => removeWord(entry.word),
              "aria-label": `Remove ${entry.word}`,
              children: "×"
            }
          )
        ] }, entry.word)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "section", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "section-title", children: "Disabled Sites" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "patterns-list", children: (settings == null ? void 0 : settings.disabledPatterns.length) === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "dictionary-empty", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No disabled site patterns." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: 'Add patterns like "*.bank.com" to disable spell checking on sensitive sites.' })
        ] }) : settings == null ? void 0 : settings.disabledPatterns.map((pattern) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pattern-item", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "pattern-value", children: pattern }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "btn-icon",
              onClick: () => removePattern(pattern),
              "aria-label": `Remove ${pattern}`,
              children: "×"
            }
          )
        ] }, pattern)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pattern-add", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pattern-input-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              className: "pattern-input",
              placeholder: "*.example.com",
              value: newPattern,
              onChange: (e) => setNewPattern(e.target.value),
              onKeyDown: (e) => e.key === "Enter" && addPattern()
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-add", onClick: addPattern, children: "Add" })
        ] }) })
      ] })
    ] }),
    modal === "import" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "modal-overlay", onClick: () => setModal(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "modal-title", children: "Import Dictionary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "modal-close", onClick: () => setModal(null), children: "×" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "modal-body", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          className: "modal-textarea",
          placeholder: "Enter words, one per line...",
          value: importText,
          onChange: (e) => setImportText(e.target.value)
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal-footer", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: () => setModal(null), children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-add", onClick: handleImport, children: "Import" })
      ] })
    ] }) }),
    modal === "export" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "modal-overlay", onClick: () => setModal(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "modal-title", children: "Export Dictionary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "modal-close", onClick: () => setModal(null), children: "×" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "modal-body", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          className: "modal-textarea",
          value: exportText,
          readOnly: true
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "modal-footer", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-secondary", onClick: () => setModal(null), children: "Close" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-add", onClick: copyExport, children: "Copy" })
      ] })
    ] }) }),
    toast && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `toast ${toast.type}`, children: toast.message })
  ] });
}
const container = document.getElementById("root");
if (container) {
  const root = createRoot(container);
  root.render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Options, {}) })
  );
}
//# sourceMappingURL=options-CEHG5ddd.js.map
