const ENGLISH_WORDS = /* @__PURE__ */ new Set([
  // Articles & Determiners
  "a",
  "an",
  "the",
  "this",
  "that",
  "these",
  "those",
  "my",
  "your",
  "his",
  "her",
  "its",
  "our",
  "their",
  "some",
  "any",
  "no",
  "every",
  "each",
  "all",
  "both",
  "few",
  "many",
  "much",
  "most",
  "other",
  "another",
  "such",
  "what",
  "which",
  "whose",
  // Pronouns
  "i",
  "me",
  "we",
  "us",
  "you",
  "he",
  "him",
  "she",
  "they",
  "them",
  "it",
  "who",
  "whom",
  "what",
  "which",
  "that",
  "whoever",
  "whatever",
  "myself",
  "yourself",
  "himself",
  "herself",
  "itself",
  "ourselves",
  "themselves",
  "everyone",
  "everything",
  "someone",
  "something",
  "anyone",
  "anything",
  "nobody",
  "nothing",
  "everybody",
  "somebody",
  // Prepositions
  "in",
  "on",
  "at",
  "to",
  "for",
  "with",
  "by",
  "from",
  "up",
  "about",
  "into",
  "through",
  "during",
  "before",
  "after",
  "above",
  "below",
  "between",
  "under",
  "again",
  "further",
  "then",
  "once",
  "here",
  "there",
  "where",
  "when",
  "why",
  "how",
  "out",
  "off",
  "over",
  "own",
  "against",
  "along",
  "among",
  "around",
  "behind",
  "beside",
  "beyond",
  "within",
  "without",
  "upon",
  "toward",
  "towards",
  "across",
  "throughout",
  "inside",
  "outside",
  // Conjunctions
  "and",
  "but",
  "or",
  "nor",
  "so",
  "yet",
  "because",
  "although",
  "while",
  "if",
  "unless",
  "until",
  "since",
  "whether",
  "though",
  "whereas",
  "however",
  "therefore",
  "moreover",
  "furthermore",
  "nevertheless",
  "meanwhile",
  "otherwise",
  "thus",
  "hence",
  // Common Verbs
  "be",
  "am",
  "is",
  "are",
  "was",
  "were",
  "been",
  "being",
  "have",
  "has",
  "had",
  "having",
  "do",
  "does",
  "did",
  "doing",
  "done",
  "will",
  "would",
  "shall",
  "should",
  "may",
  "might",
  "must",
  "can",
  "could",
  "need",
  "dare",
  "ought",
  "used",
  "go",
  "goes",
  "went",
  "going",
  "gone",
  "get",
  "gets",
  "got",
  "getting",
  "gotten",
  "make",
  "makes",
  "made",
  "making",
  "know",
  "knows",
  "knew",
  "knowing",
  "known",
  "think",
  "thinks",
  "thought",
  "thinking",
  "take",
  "takes",
  "took",
  "taking",
  "taken",
  "see",
  "sees",
  "saw",
  "seeing",
  "seen",
  "come",
  "comes",
  "came",
  "coming",
  "want",
  "wants",
  "wanted",
  "wanting",
  "look",
  "looks",
  "looked",
  "looking",
  "use",
  "uses",
  "used",
  "using",
  "find",
  "finds",
  "found",
  "finding",
  "give",
  "gives",
  "gave",
  "giving",
  "given",
  "tell",
  "tells",
  "told",
  "telling",
  "work",
  "works",
  "worked",
  "working",
  "call",
  "calls",
  "called",
  "calling",
  "try",
  "tries",
  "tried",
  "trying",
  "ask",
  "asks",
  "asked",
  "asking",
  "put",
  "puts",
  "putting",
  "mean",
  "means",
  "meant",
  "meaning",
  "keep",
  "keeps",
  "kept",
  "keeping",
  "let",
  "lets",
  "letting",
  "begin",
  "begins",
  "began",
  "beginning",
  "begun",
  "seem",
  "seems",
  "seemed",
  "seeming",
  "help",
  "helps",
  "helped",
  "helping",
  "show",
  "shows",
  "showed",
  "showing",
  "shown",
  "hear",
  "hears",
  "heard",
  "hearing",
  "play",
  "plays",
  "played",
  "playing",
  "run",
  "runs",
  "ran",
  "running",
  "move",
  "moves",
  "moved",
  "moving",
  "live",
  "lives",
  "lived",
  "living",
  "believe",
  "believes",
  "believed",
  "believing",
  "hold",
  "holds",
  "held",
  "holding",
  "bring",
  "brings",
  "brought",
  "bringing",
  "happen",
  "happens",
  "happened",
  "happening",
  "write",
  "writes",
  "wrote",
  "writing",
  "written",
  "provide",
  "provides",
  "provided",
  "providing",
  "sit",
  "sits",
  "sat",
  "sitting",
  "stand",
  "stands",
  "stood",
  "standing",
  "lose",
  "loses",
  "lost",
  "losing",
  "pay",
  "pays",
  "paid",
  "paying",
  "meet",
  "meets",
  "met",
  "meeting",
  "include",
  "includes",
  "included",
  "including",
  "continue",
  "continues",
  "continued",
  "continuing",
  "set",
  "sets",
  "setting",
  "learn",
  "learns",
  "learned",
  "learning",
  "change",
  "changes",
  "changed",
  "changing",
  "lead",
  "leads",
  "led",
  "leading",
  "understand",
  "understands",
  "understood",
  "understanding",
  "watch",
  "watches",
  "watched",
  "watching",
  "follow",
  "follows",
  "followed",
  "following",
  "stop",
  "stops",
  "stopped",
  "stopping",
  "create",
  "creates",
  "created",
  "creating",
  "speak",
  "speaks",
  "spoke",
  "speaking",
  "spoken",
  "read",
  "reads",
  "reading",
  "allow",
  "allows",
  "allowed",
  "allowing",
  "add",
  "adds",
  "added",
  "adding",
  "spend",
  "spends",
  "spent",
  "spending",
  "grow",
  "grows",
  "grew",
  "growing",
  "grown",
  "open",
  "opens",
  "opened",
  "opening",
  "walk",
  "walks",
  "walked",
  "walking",
  "win",
  "wins",
  "won",
  "winning",
  "offer",
  "offers",
  "offered",
  "offering",
  "remember",
  "remembers",
  "remembered",
  "remembering",
  "love",
  "loves",
  "loved",
  "loving",
  "consider",
  "considers",
  "considered",
  "considering",
  "appear",
  "appears",
  "appeared",
  "appearing",
  "buy",
  "buys",
  "bought",
  "buying",
  "wait",
  "waits",
  "waited",
  "waiting",
  "serve",
  "serves",
  "served",
  "serving",
  "die",
  "dies",
  "died",
  "dying",
  "send",
  "sends",
  "sent",
  "sending",
  "expect",
  "expects",
  "expected",
  "expecting",
  "build",
  "builds",
  "built",
  "building",
  "stay",
  "stays",
  "stayed",
  "staying",
  "fall",
  "falls",
  "fell",
  "falling",
  "fallen",
  "cut",
  "cuts",
  "cutting",
  "reach",
  "reaches",
  "reached",
  "reaching",
  "kill",
  "kills",
  "killed",
  "killing",
  "remain",
  "remains",
  "remained",
  "remaining",
  "suggest",
  "suggests",
  "suggested",
  "suggesting",
  "raise",
  "raises",
  "raised",
  "raising",
  "pass",
  "passes",
  "passed",
  "passing",
  "sell",
  "sells",
  "sold",
  "selling",
  "require",
  "requires",
  "required",
  "requiring",
  "report",
  "reports",
  "reported",
  "reporting",
  "decide",
  "decides",
  "decided",
  "deciding",
  "pull",
  "pulls",
  "pulled",
  "pulling",
  // Common Nouns
  "time",
  "year",
  "people",
  "way",
  "day",
  "man",
  "woman",
  "child",
  "children",
  "world",
  "life",
  "hand",
  "part",
  "place",
  "case",
  "week",
  "company",
  "system",
  "program",
  "question",
  "work",
  "government",
  "number",
  "night",
  "point",
  "home",
  "water",
  "room",
  "mother",
  "area",
  "money",
  "story",
  "fact",
  "month",
  "lot",
  "right",
  "study",
  "book",
  "eye",
  "job",
  "word",
  "business",
  "issue",
  "side",
  "kind",
  "head",
  "house",
  "service",
  "friend",
  "father",
  "power",
  "hour",
  "game",
  "line",
  "end",
  "member",
  "law",
  "car",
  "city",
  "community",
  "name",
  "president",
  "team",
  "minute",
  "idea",
  "kid",
  "body",
  "information",
  "back",
  "parent",
  "face",
  "others",
  "level",
  "office",
  "door",
  "health",
  "person",
  "art",
  "war",
  "history",
  "party",
  "result",
  "change",
  "morning",
  "reason",
  "research",
  "girl",
  "guy",
  "moment",
  "air",
  "teacher",
  "force",
  "education",
  "foot",
  "feet",
  "boy",
  "age",
  "policy",
  "process",
  "music",
  "market",
  "sense",
  "nation",
  "plan",
  "college",
  "interest",
  "death",
  "experience",
  "effect",
  "use",
  "class",
  "control",
  "care",
  "field",
  "development",
  "role",
  "effort",
  "rate",
  "heart",
  "drug",
  "show",
  "leader",
  "light",
  "voice",
  "wife",
  "police",
  "mind",
  "difference",
  "period",
  "building",
  "action",
  "attention",
  "love",
  "road",
  "price",
  "court",
  "family",
  "data",
  "decision",
  "staff",
  "practice",
  "ground",
  "form",
  "value",
  "table",
  "model",
  "relationship",
  "activity",
  "communication",
  "computer",
  "property",
  "movie",
  "window",
  "evidence",
  "loss",
  "view",
  "nature",
  "player",
  "behavior",
  "knowledge",
  "event",
  "analysis",
  "environment",
  "performance",
  "treatment",
  "truth",
  "news",
  "strategy",
  "speech",
  "technology",
  "network",
  "reality",
  "baby",
  "ability",
  "agreement",
  "audience",
  "article",
  "ball",
  "bank",
  "base",
  "bed",
  "bill",
  "bit",
  "blood",
  "board",
  "box",
  "brother",
  "budget",
  "center",
  "century",
  "challenge",
  "chance",
  "character",
  "church",
  "citizen",
  "claim",
  "coach",
  "coast",
  "coffee",
  "collection",
  "color",
  "colour",
  "comment",
  "condition",
  "conference",
  "congress",
  "connection",
  "conversation",
  "corner",
  "cost",
  "country",
  "county",
  "couple",
  "course",
  "cover",
  "crime",
  "culture",
  "cup",
  "customer",
  "daughter",
  "deal",
  "debate",
  "degree",
  "department",
  "design",
  "detail",
  "director",
  "discussion",
  "disease",
  "doctor",
  "dog",
  "doubt",
  "drive",
  "economy",
  "edge",
  "election",
  "employee",
  "energy",
  "error",
  "example",
  "exchange",
  "executive",
  "exercise",
  "expert",
  "explanation",
  "failure",
  "faith",
  "fear",
  "feeling",
  "figure",
  "film",
  "fire",
  "firm",
  "fish",
  "floor",
  "focus",
  "food",
  "football",
  "front",
  "future",
  "garden",
  "gas",
  "generation",
  "glass",
  "goal",
  "god",
  "gold",
  "growth",
  "gun",
  "hair",
  "hall",
  "heat",
  "highway",
  "hill",
  "hope",
  "horse",
  "hospital",
  "hotel",
  "husband",
  "image",
  "impact",
  "importance",
  "income",
  "individual",
  "industry",
  "injury",
  "instance",
  "institution",
  "interview",
  "investment",
  "island",
  "item",
  "judge",
  "key",
  "king",
  "kitchen",
  "lake",
  "land",
  "language",
  "lawyer",
  "league",
  "leg",
  "letter",
  "library",
  "list",
  "literature",
  "location",
  "machine",
  "magazine",
  "management",
  "manager",
  "map",
  "marriage",
  "material",
  "matter",
  "meaning",
  "measure",
  "media",
  "medicine",
  "meeting",
  "memory",
  "message",
  "method",
  "middle",
  "military",
  "milk",
  "mission",
  "mistake",
  "moment",
  "movement",
  "murder",
  "museum",
  "neighborhood",
  "newspaper",
  "none",
  "note",
  "notice",
  "object",
  "occasion",
  "oil",
  "operation",
  "opinion",
  "opportunity",
  "option",
  "order",
  "organization",
  "owner",
  "page",
  "pain",
  "painting",
  "pair",
  "paper",
  "park",
  "partner",
  "past",
  "path",
  "patient",
  "pattern",
  "peace",
  "phone",
  "photograph",
  "picture",
  "piece",
  "plant",
  "plate",
  "pleasure",
  "pocket",
  "poem",
  "poet",
  "pool",
  "population",
  "position",
  "possibility",
  "potential",
  "presence",
  "pressure",
  "principle",
  "prison",
  "problem",
  "procedure",
  "production",
  "profession",
  "professor",
  "profit",
  "progress",
  "project",
  "promise",
  "protection",
  "public",
  "purpose",
  "quality",
  "race",
  "radio",
  "range",
  "reaction",
  "reader",
  "record",
  "reduction",
  "region",
  "religion",
  "representative",
  "request",
  "resource",
  "response",
  "responsibility",
  "rest",
  "restaurant",
  "return",
  "revolution",
  "ring",
  "risk",
  "river",
  "rock",
  "rule",
  "safety",
  "sale",
  "sample",
  "scale",
  "scene",
  "school",
  "science",
  "scientist",
  "score",
  "sea",
  "search",
  "season",
  "seat",
  "second",
  "section",
  "sector",
  "security",
  "selection",
  "self",
  "senate",
  "senator",
  "series",
  "sex",
  "shape",
  "share",
  "shot",
  "shoulder",
  "sign",
  "significance",
  "silence",
  "silver",
  "singer",
  "sister",
  "site",
  "situation",
  "size",
  "skill",
  "skin",
  "sleep",
  "smile",
  "snow",
  "society",
  "soil",
  "soldier",
  "solution",
  "son",
  "song",
  "sort",
  "sound",
  "source",
  "south",
  "space",
  "species",
  "spirit",
  "sport",
  "spot",
  "spring",
  "square",
  "stage",
  "standard",
  "star",
  "start",
  "state",
  "statement",
  "station",
  "status",
  "step",
  "stock",
  "stone",
  "store",
  "stranger",
  "street",
  "strength",
  "stress",
  "structure",
  "student",
  "stuff",
  "style",
  "subject",
  "success",
  "summer",
  "sun",
  "support",
  "surface",
  "surprise",
  "survey",
  "symbol",
  "target",
  "task",
  "tax",
  "tea",
  "technique",
  "television",
  "temperature",
  "term",
  "test",
  "text",
  "theory",
  "thing",
  "thought",
  "threat",
  "title",
  "today",
  "tomorrow",
  "tone",
  "tool",
  "top",
  "topic",
  "total",
  "touch",
  "tour",
  "town",
  "track",
  "trade",
  "tradition",
  "traffic",
  "training",
  "travel",
  "tree",
  "trend",
  "trial",
  "trip",
  "trouble",
  "truck",
  "trust",
  "turn",
  "type",
  "understanding",
  "union",
  "unit",
  "university",
  "user",
  "variety",
  "version",
  "victim",
  "video",
  "village",
  "violence",
  "vision",
  "visit",
  "visitor",
  "volume",
  "vote",
  "wall",
  "weather",
  "website",
  "weekend",
  "weight",
  "west",
  "wind",
  "window",
  "winter",
  "wood",
  "worker",
  "writer",
  "writing",
  "yesterday",
  "youth",
  // Common Adjectives
  "good",
  "new",
  "first",
  "last",
  "long",
  "great",
  "little",
  "own",
  "other",
  "old",
  "right",
  "big",
  "high",
  "different",
  "small",
  "large",
  "next",
  "early",
  "young",
  "important",
  "few",
  "public",
  "bad",
  "same",
  "able",
  "free",
  "sure",
  "clear",
  "full",
  "special",
  "easy",
  "strong",
  "certain",
  "local",
  "recent",
  "true",
  "hard",
  "best",
  "better",
  "general",
  "specific",
  "possible",
  "real",
  "major",
  "personal",
  "current",
  "national",
  "natural",
  "physical",
  "short",
  "common",
  "single",
  "open",
  "simple",
  "whole",
  "ready",
  "available",
  "likely",
  "similar",
  "present",
  "economic",
  "private",
  "past",
  "foreign",
  "fine",
  "serious",
  "late",
  "human",
  "central",
  "necessary",
  "low",
  "close",
  "happy",
  "social",
  "beautiful",
  "nice",
  "popular",
  "final",
  "poor",
  "main",
  "wrong",
  "hot",
  "cold",
  "modern",
  "dark",
  "various",
  "entire",
  "basic",
  "particular",
  "positive",
  "financial",
  "international",
  "political",
  "medical",
  "traditional",
  "potential",
  "professional",
  "average",
  "successful",
  "independent",
  "significant",
  "individual",
  "interesting",
  "appropriate",
  "additional",
  "effective",
  "commercial",
  "environmental",
  "critical",
  "original",
  "normal",
  "regular",
  "official",
  "responsible",
  "military",
  "cultural",
  "educational",
  "federal",
  "legal",
  "technical",
  "religious",
  "sexual",
  "historical",
  "mental",
  "global",
  "civil",
  "powerful",
  "industrial",
  "corporate",
  "digital",
  "electronic",
  "creative",
  "academic",
  "essential",
  "comprehensive",
  "practical",
  "typical",
  "perfect",
  "wonderful",
  "impossible",
  "terrible",
  "horrible",
  "excellent",
  "fantastic",
  "incredible",
  "amazing",
  "awesome",
  "awful",
  "obvious",
  "careful",
  "dangerous",
  "famous",
  "nervous",
  "comfortable",
  "competitive",
  "expensive",
  "impressive",
  "massive",
  "sensitive",
  "alternative",
  "conservative",
  "progressive",
  "aggressive",
  "negative",
  "positive",
  "relative",
  "active",
  "attractive",
  "creative",
  "effective",
  "expensive",
  "extensive",
  "native",
  "objective",
  "productive",
  "protective",
  "selective",
  "alive",
  "alone",
  "asleep",
  "aware",
  "capable",
  "familiar",
  "former",
  "latter",
  "previous",
  "prior",
  "separate",
  "following",
  "remaining",
  "existing",
  "growing",
  "leading",
  "living",
  "missing",
  "ongoing",
  "outstanding",
  "promising",
  "surprising",
  "underlying",
  "willing",
  "working",
  "advanced",
  "increased",
  "limited",
  "reduced",
  "related",
  "required",
  "supposed",
  "united",
  "used",
  "worried",
  "domestic",
  "ethnic",
  "rural",
  "urban",
  "ancient",
  "contemporary",
  "democratic",
  "dramatic",
  "economic",
  "electric",
  "genetic",
  "organic",
  "romantic",
  "scientific",
  "strategic",
  "systematic",
  "automatic",
  "athletic",
  "authentic",
  "chronic",
  "classic",
  "cosmic",
  "dynamic",
  "exotic",
  "fantastic",
  "graphic",
  "historic",
  "magic",
  "magnetic",
  "plastic",
  "symbolic",
  "tragic",
  // Common Adverbs
  "not",
  "also",
  "very",
  "often",
  "just",
  "only",
  "well",
  "even",
  "still",
  "already",
  "always",
  "never",
  "now",
  "really",
  "actually",
  "probably",
  "usually",
  "especially",
  "quite",
  "rather",
  "almost",
  "finally",
  "perhaps",
  "simply",
  "sometimes",
  "certainly",
  "generally",
  "particularly",
  "recently",
  "clearly",
  "quickly",
  "easily",
  "exactly",
  "directly",
  "immediately",
  "completely",
  "absolutely",
  "naturally",
  "obviously",
  "definitely",
  "certainly",
  "seriously",
  "relatively",
  "apparently",
  "eventually",
  "essentially",
  "basically",
  "typically",
  "previously",
  "currently",
  "originally",
  "increasingly",
  "significantly",
  "specifically",
  "necessarily",
  "potentially",
  "approximately",
  "fortunately",
  "unfortunately",
  "hopefully",
  "literally",
  "personally",
  "physically",
  "mentally",
  "financially",
  "politically",
  "socially",
  "publicly",
  "privately",
  "properly",
  "correctly",
  "directly",
  "strongly",
  "highly",
  "deeply",
  "widely",
  "closely",
  "frequently",
  "constantly",
  "regularly",
  "normally",
  "extremely",
  "entirely",
  "largely",
  "merely",
  "mostly",
  "nearly",
  "partly",
  "slightly",
  "somewhat",
  "totally",
  "truly",
  "virtually",
  "gradually",
  "rapidly",
  "slowly",
  "carefully",
  "fully",
  "suddenly",
  "successfully",
  "effectively",
  "accordingly",
  "consequently",
  "meanwhile",
  "otherwise",
  "therefore",
  "furthermore",
  "moreover",
  "nevertheless",
  "nonetheless",
  "however",
  "instead",
  "elsewhere",
  "everywhere",
  "nowhere",
  "anywhere",
  "somewhere",
  "here",
  "there",
  "home",
  "away",
  "back",
  "together",
  "apart",
  "alone",
  "ahead",
  "behind",
  "below",
  "beneath",
  "beside",
  "besides",
  "between",
  "beyond",
  "inside",
  "outside",
  "underneath",
  "upstairs",
  "downstairs",
  "nearby",
  "overseas",
  "tomorrow",
  "yesterday",
  "today",
  "tonight",
  "ago",
  "soon",
  "later",
  "lately",
  "recently",
  "before",
  "after",
  "since",
  "then",
  "when",
  "while",
  "once",
  "twice",
  // Numbers (spelled out)
  "zero",
  "one",
  "two",
  "three",
  "four",
  "five",
  "six",
  "seven",
  "eight",
  "nine",
  "ten",
  "eleven",
  "twelve",
  "thirteen",
  "fourteen",
  "fifteen",
  "sixteen",
  "seventeen",
  "eighteen",
  "nineteen",
  "twenty",
  "thirty",
  "forty",
  "fifty",
  "sixty",
  "seventy",
  "eighty",
  "ninety",
  "hundred",
  "thousand",
  "million",
  "billion",
  "trillion",
  "first",
  "second",
  "third",
  "fourth",
  "fifth",
  "sixth",
  "seventh",
  "eighth",
  "ninth",
  "tenth",
  "half",
  "quarter",
  "double",
  "triple",
  // Days and months
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
  "sunday",
  "january",
  "february",
  "march",
  "april",
  "may",
  "june",
  "july",
  "august",
  "september",
  "october",
  "november",
  "december",
  // Common contractions (without apostrophe for simple checking)
  "don't",
  "doesn't",
  "didn't",
  "won't",
  "wouldn't",
  "can't",
  "couldn't",
  "shouldn't",
  "isn't",
  "aren't",
  "wasn't",
  "weren't",
  "haven't",
  "hasn't",
  "hadn't",
  "i'm",
  "i've",
  "i'll",
  "i'd",
  "you're",
  "you've",
  "you'll",
  "you'd",
  "he's",
  "he'll",
  "he'd",
  "she's",
  "she'll",
  "she'd",
  "it's",
  "it'll",
  "we're",
  "we've",
  "we'll",
  "we'd",
  "they're",
  "they've",
  "they'll",
  "they'd",
  "that's",
  "that'll",
  "that'd",
  "who's",
  "who'll",
  "who'd",
  "what's",
  "what'll",
  "what'd",
  "where's",
  "where'll",
  "where'd",
  "when's",
  "when'll",
  "when'd",
  "why's",
  "why'll",
  "why'd",
  "how's",
  "how'll",
  "how'd",
  "there's",
  "there'll",
  "there'd",
  "here's",
  "let's",
  "ain't",
  "o'clock",
  // Tech terms
  "app",
  "apps",
  "blog",
  "browser",
  "click",
  "cloud",
  "code",
  "coding",
  "cookie",
  "cookies",
  "cyber",
  "database",
  "desktop",
  "download",
  "downloads",
  "email",
  "emails",
  "emoji",
  "file",
  "files",
  "folder",
  "folders",
  "google",
  "hack",
  "hacker",
  "hackers",
  "hashtag",
  "homepage",
  "icon",
  "icons",
  "inbox",
  "internet",
  "keyboard",
  "laptop",
  "laptops",
  "link",
  "links",
  "login",
  "logout",
  "malware",
  "menu",
  "mobile",
  "monitor",
  "mouse",
  "network",
  "networks",
  "offline",
  "online",
  "password",
  "passwords",
  "pixel",
  "pixels",
  "plugin",
  "plugins",
  "podcast",
  "popup",
  "profile",
  "router",
  "screenshot",
  "screenshots",
  "search",
  "server",
  "servers",
  "settings",
  "setup",
  "smartphone",
  "smartphones",
  "software",
  "spam",
  "startup",
  "startups",
  "sync",
  "tablet",
  "tablets",
  "tech",
  "template",
  "templates",
  "touchscreen",
  "tweet",
  "tweets",
  "update",
  "updates",
  "upgrade",
  "upgrades",
  "upload",
  "uploads",
  "url",
  "urls",
  "username",
  "usernames",
  "video",
  "videos",
  "viral",
  "virus",
  "viruses",
  "web",
  "webcam",
  "webpage",
  "webpages",
  "website",
  "websites",
  "wifi",
  "wireless",
  "www",
  "api",
  "backend",
  "frontend",
  "css",
  "html",
  "http",
  "https",
  "javascript",
  "json",
  "php",
  "python",
  "sql",
  "typescript",
  "github",
  "git",
  "repo",
  "repository",
  // Additional common words
  "ok",
  "okay",
  "yeah",
  "yes",
  "no",
  "maybe",
  "please",
  "thanks",
  "thank",
  "sorry",
  "hello",
  "hi",
  "hey",
  "bye",
  "goodbye",
  "welcome",
  "congrats",
  "congratulations",
  "etc",
  "vs",
  "ie",
  "eg",
  "mr",
  "mrs",
  "ms",
  "dr",
  "jr",
  "sr",
  "inc",
  "ltd",
  "co",
  "llc",
  "corp",
  "plc",
  "org",
  "gov",
  "edu",
  "com",
  "net",
  "info",
  // Common words often used in tests/examples
  "quick",
  "brown",
  "fox",
  "jumps",
  "jump",
  "jumped",
  "jumping",
  "over",
  "lazy",
  "dog",
  "dogs",
  "cat",
  "cats",
  "red",
  "blue",
  "green",
  "yellow",
  "black",
  "white",
  "pink",
  "purple",
  "orange",
  "grey",
  "gray",
  "fast",
  "slow",
  "big",
  "tall",
  "short",
  "wide",
  "narrow",
  "thick",
  "thin",
  "heavy",
  "light",
  "soft",
  "loud",
  "quiet",
  "wet",
  "dry",
  "clean",
  "dirty",
  "empty",
  "bright",
  "sweet",
  "sour",
  "bitter",
  "salty",
  "fresh",
  "stale",
  "rough",
  "smooth",
  "sharp",
  "dull",
  "round",
  "flat",
  "straight",
  "curved",
  // Extended vocabulary - Academic & Professional
  "academic",
  "academy",
  "accept",
  "acceptance",
  "access",
  "accessible",
  "accident",
  "accomplish",
  "accomplishment",
  "account",
  "accounting",
  "accurate",
  "achieve",
  "achievement",
  "acknowledge",
  "acknowledgment",
  "acquire",
  "acquisition",
  "across",
  "act",
  "action",
  "active",
  "activity",
  "actor",
  "actress",
  "actual",
  "actually",
  "adapt",
  "adaptation",
  "add",
  "addition",
  "additional",
  "address",
  "adequate",
  "adjust",
  "adjustment",
  "administration",
  "administrative",
  "administrator",
  "admire",
  "admission",
  "admit",
  "adopt",
  "adoption",
  "adult",
  "advance",
  "advanced",
  "advantage",
  "adventure",
  "advertise",
  "advertisement",
  "advice",
  "advise",
  "advisor",
  "advocate",
  "affair",
  "affect",
  "affection",
  "afford",
  "afraid",
  "afternoon",
  "afterward",
  "again",
  "against",
  "age",
  "agency",
  "agenda",
  "agent",
  "aggressive",
  "ago",
  "agree",
  "agreement",
  "agricultural",
  "agriculture",
  "ahead",
  "aid",
  "aim",
  "air",
  "aircraft",
  "airline",
  "airport",
  "alarm",
  "album",
  "alcohol",
  "alive",
  "all",
  "allege",
  "allegation",
  "alliance",
  "allow",
  "ally",
  "almost",
  "alone",
  "along",
  "already",
  "also",
  "alter",
  "alternative",
  "although",
  "always",
  "amazing",
  "ambition",
  "ambitious",
  "amendment",
  "among",
  "amount",
  "analysis",
  "analyst",
  "analyze",
  "ancient",
  "and",
  "anger",
  "angle",
  "angry",
  "animal",
  "announce",
  "announcement",
  "annual",
  "another",
  "answer",
  "anticipate",
  "anxiety",
  "anxious",
  "any",
  "anybody",
  "anymore",
  "anyone",
  "anything",
  "anyway",
  "anywhere",
  "apart",
  "apartment",
  "apologize",
  "apology",
  "apparent",
  "apparently",
  "appeal",
  "appear",
  "appearance",
  "apple",
  "application",
  "apply",
  "appoint",
  "appointment",
  "appreciate",
  "approach",
  "appropriate",
  "approval",
  "approve",
  "approximately",
  "architect",
  "architecture",
  "area",
  "argue",
  "argument",
  "arise",
  "arm",
  "armed",
  "army",
  "around",
  "arrange",
  "arrangement",
  "arrest",
  "arrival",
  "arrive",
  "arrow",
  "art",
  "article",
  "artist",
  "artistic",
  "as",
  "ashamed",
  "aside",
  "ask",
  "asleep",
  "aspect",
  "assault",
  "assert",
  "assess",
  "assessment",
  "asset",
  "assign",
  "assignment",
  "assist",
  "assistance",
  "assistant",
  "associate",
  "association",
  "assume",
  "assumption",
  "assure",
  "at",
  "athlete",
  "athletic",
  "atmosphere",
  "attach",
  "attack",
  "attempt",
  "attend",
  "attention",
  "attitude",
  "attorney",
  "attract",
  "attraction",
  "attractive",
  "attribute",
  "audience",
  "author",
  "authority",
  "authorize",
  "auto",
  "automatic",
  "automatically",
  "automobile",
  "autumn",
  "available",
  "average",
  "avoid",
  "award",
  "aware",
  "awareness",
  "away",
  "awful",
  "baby",
  "back",
  "background",
  "backward",
  "bad",
  "badly",
  "bag",
  "bake",
  "balance",
  "ball",
  "ban",
  "band",
  "bank",
  "bar",
  "barely",
  "barrel",
  "barrier",
  "base",
  "baseball",
  "basic",
  "basically",
  "basis",
  "basket",
  "basketball",
  "bath",
  "bathroom",
  "battery",
  "battle",
  "be",
  "beach",
  "bean",
  "bear",
  "beat",
  "beautiful",
  "beauty",
  "because",
  "become",
  "bed",
  "bedroom",
  "beer",
  "before",
  "begin",
  "beginning",
  "behavior",
  "behind",
  "being",
  "belief",
  "believe",
  "bell",
  "belong",
  "below",
  "belt",
  "bench",
  "bend",
  "beneath",
  "benefit",
  "beside",
  "besides",
  "best",
  "bet",
  "better",
  "between",
  "beyond",
  "bias",
  "bicycle",
  "bid",
  "big",
  "bike",
  "bill",
  "billion",
  "bind",
  "biological",
  "biology",
  "bird",
  "birth",
  "birthday",
  "bit",
  "bite",
  "bitter",
  "black",
  "blade",
  "blame",
  "blank",
  "blanket",
  "blind",
  "block",
  "blood",
  "blow",
  "blue",
  "board",
  "boat",
  "body",
  "boil",
  "bold",
  "bomb",
  "bond",
  "bone",
  "book",
  "boom",
  "boot",
  "border",
  "bore",
  "boring",
  "born",
  "borrow",
  "boss",
  "both",
  "bother",
  "bottle",
  "bottom",
  "boundary",
  "bowl",
  "box",
  "boy",
  "brain",
  "branch",
  "brand",
  "brave",
  "bread",
  "break",
  "breakfast",
  "breast",
  "breath",
  "breathe",
  "breathing",
  "breed",
  "brick",
  "bridge",
  "brief",
  "briefly",
  "bright",
  "brilliant",
  "bring",
  "broad",
  "broadcast",
  "broken",
  "brother",
  "brown",
  "brush",
  "buck",
  "budget",
  "build",
  "building",
  "bullet",
  "bunch",
  "burden",
  "burn",
  "bury",
  "bus",
  "bush",
  "business",
  "busy",
  "but",
  "butter",
  "button",
  "buy",
  "buyer",
  "by",
  "cabin",
  "cabinet",
  "cable",
  "cake",
  "calculate",
  "call",
  "calm",
  "camera",
  "camp",
  "campaign",
  "campus",
  "can",
  "cancel",
  "cancer",
  "candidate",
  "candle",
  "candy",
  "cap",
  "capability",
  "capable",
  "capacity",
  "capital",
  "captain",
  "capture",
  "car",
  "carbon",
  "card",
  "care",
  "career",
  "careful",
  "carefully",
  "carrier",
  "carry",
  "case",
  "cash",
  "cast",
  "casual",
  "cat",
  "catch",
  "category",
  "cattle",
  "cause",
  "ceiling",
  "celebrate",
  "celebration",
  "celebrity",
  "cell",
  "cent",
  "center",
  "central",
  "century",
  "ceremony",
  "certain",
  "certainly",
  "chain",
  "chair",
  "chairman",
  "challenge",
  "chamber",
  "champion",
  "championship",
  "chance",
  "change",
  "changing",
  "channel",
  "chapter",
  "character",
  "characteristic",
  "characterize",
  "charge",
  "charity",
  "chart",
  "chase",
  "cheap",
  "check",
  "cheek",
  "cheese",
  "chef",
  "chemical",
  "chest",
  "chicken",
  "chief",
  "child",
  "childhood",
  "chip",
  "chocolate",
  "choice",
  "cholesterol",
  "choose",
  "chop",
  "church",
  "cigarette",
  "circle",
  "circumstance",
  "cite",
  "citizen",
  "city",
  "civil",
  "civilian",
  "claim",
  "class",
  "classic",
  "classroom",
  "clay",
  "clean",
  "clear",
  "clearly",
  "clerk",
  "click",
  "client",
  "cliff",
  "climate",
  "climb",
  "clinic",
  "clinical",
  "clock",
  "close",
  "closely",
  "closer",
  "clothes",
  "clothing",
  "cloud",
  "club",
  "clue",
  "cluster",
  "coach",
  "coal",
  "coalition",
  "coast",
  "coat",
  "code",
  "coffee",
  "cognitive",
  "cold",
  "collapse",
  "colleague",
  "collect",
  "collection",
  "collective",
  "college",
  "colonial",
  "colony",
  "color",
  "column",
  "combination",
  "combine",
  "come",
  "comedy",
  "comfort",
  "comfortable",
  "command",
  "commander",
  "comment",
  "commercial",
  "commission",
  "commissioner",
  "commit",
  "commitment",
  "committee",
  "common",
  "commonly",
  "communicate",
  "communication",
  "community",
  "company",
  "compare",
  "comparison",
  "compete",
  "competition",
  "competitive",
  "competitor",
  "complain",
  "complaint",
  "complete",
  "completely",
  "complex",
  "complicated",
  "component",
  "compose",
  "composition",
  "comprehensive",
  "computer",
  "concentrate",
  "concentration",
  "concept",
  "concern",
  "concerned",
  "concert",
  "conclude",
  "conclusion",
  "concrete",
  "condition",
  "conduct",
  "conference",
  "confidence",
  "confident",
  "confirm",
  "conflict",
  "confront",
  "confusion",
  "congress",
  "congressional",
  "connect",
  "connection",
  "consciousness",
  "consensus",
  "consequence",
  "conservative",
  "consider",
  "considerable",
  "consideration",
  "consist",
  "consistent",
  "constant",
  "constantly",
  "constitute",
  "constitutional",
  "construct",
  "construction",
  "consultant",
  "consume",
  "consumer",
  "consumption",
  "contact",
  "contain",
  "container",
  "contemporary",
  "content",
  "contest",
  "context",
  "continue",
  "continued",
  "contract",
  "contrast",
  "contribute",
  "contribution",
  "control",
  "controversial",
  "controversy",
  "convention",
  "conventional",
  "conversation",
  "convert",
  "conviction",
  "convince",
  "cook",
  "cookie",
  "cooking",
  "cool",
  "cooperation",
  "cop",
  "cope",
  "copy",
  "core",
  "corn",
  "corner",
  "corporate",
  "corporation",
  "correct",
  "correctly",
  "cost",
  "cotton",
  "couch",
  "could",
  "council",
  "counselor",
  "count",
  "counter",
  "country",
  "county",
  "couple",
  "courage",
  "course",
  "court",
  "cousin",
  "cover",
  "coverage",
  "cow",
  "crack",
  "craft",
  "crash",
  "crazy",
  "cream",
  "create",
  "creation",
  "creative",
  "creature",
  "credit",
  "crew",
  "crime",
  "criminal",
  "crisis",
  "critic",
  "critical",
  "criticism",
  "criticize",
  "crop",
  "cross",
  "crowd",
  "crucial",
  "cry",
  "cultural",
  "culture",
  "cup",
  "cure",
  "curious",
  "current",
  "currently",
  "curriculum",
  "curtain",
  "curve",
  "custom",
  "customer",
  "cut",
  "cute",
  "cycle",
  "dad",
  "daily",
  "damage",
  "dance",
  "dancer",
  "danger",
  "dangerous",
  "dare",
  "dark",
  "darkness",
  "data",
  "date",
  "daughter",
  "dawn",
  "day",
  "dead",
  "deal",
  "dealer",
  "dear",
  "death",
  "debate",
  "debt",
  "decade",
  "decide",
  "decision",
  "deck",
  "declare",
  "decline",
  "decrease",
  "deep",
  "deeply",
  "deer",
  "defeat",
  "defend",
  "defendant",
  "defense",
  "defensive",
  "deficit",
  "define",
  "definitely",
  "definition",
  "degree",
  "delay",
  "deliver",
  "delivery",
  "demand",
  "democracy",
  "democratic",
  "democrat",
  "demonstrate",
  "demonstration",
  "deny",
  "department",
  "departure",
  "depend",
  "dependent",
  "depending",
  "depict",
  "depression",
  "depth",
  "deputy",
  "derive",
  "describe",
  "description",
  "desert",
  "deserve",
  "design",
  "designer",
  "desire",
  "desk",
  "desperate",
  "despite",
  "destroy",
  "destruction",
  "detail",
  "detailed",
  "detect",
  "determine",
  "develop",
  "developing",
  "development",
  "device",
  "devote",
  "dialogue",
  "die",
  "diet",
  "differ",
  "difference",
  "different",
  "differently",
  "difficult",
  "difficulty",
  "dig",
  "digital",
  "dimension",
  "dining",
  "dinner",
  "direct",
  "direction",
  "directly",
  "director",
  "dirt",
  "dirty",
  "disability",
  "disagree",
  "disappear",
  "disaster",
  "discipline",
  "discourse",
  "discover",
  "discovery",
  "discrimination",
  "discuss",
  "discussion",
  "disease",
  "dish",
  "dismiss",
  "disorder",
  "display",
  "dispute",
  "distance",
  "distant",
  "distinct",
  "distinction",
  "distinguish",
  "distribute",
  "distribution",
  "district",
  "diverse",
  "diversity",
  "divide",
  "division",
  "divorce",
  "dna",
  "do",
  "doctor",
  "document",
  "dog",
  "domestic",
  "dominant",
  "dominate",
  "door",
  "double",
  "doubt",
  "down",
  "downtown",
  "dozen",
  "draft",
  "drag",
  "drama",
  "dramatic",
  "dramatically",
  "draw",
  "drawing",
  "dream",
  "dress",
  "drink",
  "drive",
  "driver",
  "drop",
  "drug",
  "dry",
  "due",
  "during",
  "dust",
  "duty",
  "each",
  "eager",
  "ear",
  "early",
  "earn",
  "earth",
  "ease",
  "easily",
  "east",
  "eastern",
  "easy",
  "eat",
  "economic",
  "economics",
  "economist",
  "economy",
  "edge",
  "edition",
  "editor",
  "educate",
  "education",
  "educational",
  "educator",
  "effect",
  "effective",
  "effectively",
  "efficiency",
  "efficient",
  "effort",
  "egg",
  "eight",
  "either",
  "elderly",
  "elect",
  "election",
  "electric",
  "electricity",
  "electronic",
  "element",
  "elementary",
  "eliminate",
  "elite",
  "else",
  "elsewhere",
  "email",
  "embrace",
  "emerge",
  "emergency",
  "emission",
  "emotion",
  "emotional",
  "emperor",
  "emphasis",
  "emphasize",
  "employ",
  "employee",
  "employer",
  "employment",
  "empty",
  "enable",
  "encounter",
  "encourage",
  "end",
  "enemy",
  "energy",
  "enforcement",
  "engage",
  "engine",
  "engineer",
  "engineering",
  "english",
  "enhance",
  "enjoy",
  "enormous",
  "enough",
  "ensure",
  "enter",
  "enterprise",
  "entertainment",
  "entire",
  "entirely",
  "entrance",
  "entry",
  "environment",
  "environmental",
  "episode",
  "equal",
  "equally",
  "equation",
  "equipment",
  "era",
  "error",
  "escape",
  "especially",
  "essay",
  "essential",
  "essentially",
  "establish",
  "establishment",
  "estate",
  "estimate",
  "etc",
  "ethnic",
  "european",
  "evaluate",
  "evaluation",
  "even",
  "evening",
  "event",
  "eventually",
  "ever",
  "every",
  "everybody",
  "everyday",
  "everyone",
  "everything",
  "everywhere",
  "evidence",
  "evolution",
  "evolve",
  "exact",
  "exactly",
  "examination",
  "examine",
  "example",
  "exceed",
  "excellent",
  "except",
  "exception",
  "exchange",
  "excited",
  "excitement",
  "exciting",
  "exclude",
  "excuse",
  "execute",
  "execution",
  "executive",
  "exercise",
  "exhibit",
  "exhibition",
  "exist",
  "existence",
  "existing",
  "expand",
  "expansion",
  "expect",
  "expectation",
  "expense",
  "expensive",
  "experience",
  "experiment",
  "expert",
  "explain",
  "explanation",
  "explode",
  "explore",
  "explosion",
  "expose",
  "exposure",
  "express",
  "expression",
  "extend",
  "extension",
  "extensive",
  "extent",
  "external",
  "extra",
  "extraordinary",
  "extreme",
  "extremely",
  "eye",
  "fabric",
  "face",
  "facility",
  "fact",
  "factor",
  "factory",
  "faculty",
  "fade",
  "fail",
  "failure",
  "fair",
  "fairly",
  "faith",
  "fall",
  "false",
  "familiar",
  "family",
  "famous",
  "fan",
  "fancy",
  "fantasy",
  "far",
  "farm",
  "farmer",
  "fashion",
  "fast",
  "fat",
  "fate",
  "father",
  "fault",
  "favor",
  "favorite",
  "fear",
  "feature",
  "federal",
  "fee",
  "feed",
  "feel",
  "feeling",
  "fellow",
  "female",
  "fence",
  "few",
  "fewer",
  "fiber",
  "fiction",
  "field",
  "fifteen",
  "fifth",
  "fifty",
  "fight",
  "fighter",
  "fighting",
  "figure",
  "file",
  "fill",
  "film",
  "final",
  "finally",
  "finance",
  "financial",
  "find",
  "finding",
  "fine",
  "finger",
  "finish",
  "fire",
  "firm",
  "first",
  "fish",
  "fishing",
  "fit",
  "fitness",
  "five",
  "fix",
  "flag",
  "flame",
  "flat",
  "flavor",
  "flee",
  "flesh",
  "flight",
  "float",
  "floor",
  "flow",
  "flower",
  "fly",
  "focus",
  "folk",
  "follow",
  "following",
  "food",
  "foot",
  "football",
  "for",
  "force",
  "foreign",
  "forest",
  "forever",
  "forget",
  "form",
  "formal",
  "formation",
  "former",
  "formula",
  "forth",
  "fortune",
  "forward",
  "found",
  "foundation",
  "founder",
  "four",
  "fourth",
  "frame",
  "framework",
  "free",
  "freedom",
  "freeze",
  "french",
  "frequency",
  "frequent",
  "frequently",
  "fresh",
  "friend",
  "friendly",
  "friendship",
  "from",
  "front",
  "fruit",
  "frustration",
  "fuel",
  "full",
  "fully",
  "fun",
  "function",
  "fund",
  "fundamental",
  "funding",
  "funeral",
  "funny",
  "furniture",
  "furthermore",
  "future",
  "gain",
  "galaxy",
  "gallery",
  "game",
  "gang",
  "gap",
  "garage",
  "garden",
  "garlic",
  "gas",
  "gate",
  "gather",
  "gay",
  "gaze",
  "gear",
  "gender",
  "gene",
  "general",
  "generally",
  "generate",
  "generation",
  "genetic",
  "genius",
  "genre",
  "gentle",
  "gentleman",
  "gently",
  "genuine",
  "get",
  "ghost",
  "giant",
  "gift",
  "gifted",
  "girl",
  "girlfriend",
  "give",
  "glad",
  "glance",
  "glass",
  "global",
  "globe",
  "glory",
  "go",
  "goal",
  "god",
  "gold",
  "golden",
  "golf",
  "good",
  "government",
  "governor",
  "grab",
  "grade",
  "gradually",
  "graduate",
  "grain",
  "grand",
  "grandfather",
  "grandmother",
  "grant",
  "grass",
  "grave",
  "gray",
  "great",
  "greatest",
  "greatly",
  "green",
  "greet",
  "grocery",
  "ground",
  "group",
  "grow",
  "growing",
  "growth",
  "guarantee",
  "guard",
  "guess",
  "guest",
  "guide",
  "guideline",
  "guilty",
  "gun",
  "guy",
  "habit",
  "habitat",
  "hair",
  "half",
  "hall",
  "hand",
  "handle",
  "hang",
  "happen",
  "happily",
  "happiness",
  "happy",
  "hard",
  "hardly",
  "hat",
  "hate",
  "have",
  "he",
  "head",
  "headline",
  "headquarters",
  "health",
  "healthy",
  "hear",
  "hearing",
  "heart",
  "heat",
  "heaven",
  "heavily",
  "heavy",
  "heel",
  "height",
  "helicopter",
  "hell",
  "hello",
  "help",
  "helpful",
  "her",
  "here",
  "heritage",
  "hero",
  "herself",
  "hey",
  "hi",
  "hide",
  "high",
  "highlight",
  "highly",
  "highway",
  "hill",
  "him",
  "himself",
  "hip",
  "hire",
  "his",
  "historian",
  "historic",
  "historical",
  "history",
  "hit",
  "hold",
  "hole",
  "holiday",
  "holy",
  "home",
  "homeless",
  "honest",
  "honey",
  "honor",
  "hope",
  "horizon",
  "horror",
  "horse",
  "hospital",
  "host",
  "hot",
  "hotel",
  "hour",
  "house",
  "household",
  "housing",
  "how",
  "however",
  "huge",
  "human",
  "humor",
  "hundred",
  "hungry",
  "hunt",
  "hunter",
  "hunting",
  "hurt",
  "husband",
  "hypothesis",
  "i",
  "ice",
  "idea",
  "ideal",
  "identification",
  "identify",
  "identity",
  "ie",
  "if",
  "ignore",
  "ill",
  "illegal",
  "illness",
  "illustrate",
  "image",
  "imagination",
  "imagine",
  "immediate",
  "immediately",
  "immigrant",
  "immigration",
  "impact",
  "implement",
  "implementation",
  "implication",
  "imply",
  "importance",
  "important",
  "impose",
  "impossible",
  "impress",
  "impression",
  "impressive",
  "improve",
  "improvement",
  "in",
  "incentive",
  "incident",
  "include",
  "including",
  "income",
  "incorporate",
  "increase",
  "increased",
  "increasing",
  "increasingly",
  "incredible",
  "indeed",
  "independence",
  "independent",
  "index",
  "indicate",
  "indication",
  "individual",
  "industrial",
  "industry",
  "inevitable",
  "infant",
  "infection",
  "inflation",
  "influence",
  "inform",
  "information",
  "ingredient",
  "initial",
  "initially",
  "initiative",
  "injury",
  "inner",
  "innocent",
  "innovation",
  "input",
  "inquiry",
  "inside",
  "insight",
  "insist",
  "inspire",
  "install",
  "instance",
  "instead",
  "institution",
  "institutional",
  "instruction",
  "instructor",
  "instrument",
  "insurance",
  "intellectual",
  "intelligence",
  "intend",
  "intense",
  "intensity",
  "intention",
  "interaction",
  "interest",
  "interested",
  "interesting",
  "internal",
  "international",
  "internet",
  "interpret",
  "interpretation",
  "intervention",
  "interview",
  "into",
  "introduce",
  "introduction",
  "invasion",
  "invest",
  "investigate",
  "investigation",
  "investigator",
  "investment",
  "investor",
  "invite",
  "involve",
  "involved",
  "involvement",
  "iron",
  "island",
  "isolate",
  "issue",
  "it",
  "item",
  "its",
  "itself",
  "jacket",
  "jail",
  "jet",
  "jewelry",
  "job",
  "join",
  "joint",
  "joke",
  "journal",
  "journalist",
  "journey",
  "joy",
  "judge",
  "judgment",
  "juice",
  "jump",
  "junior",
  "jury",
  "just",
  "justice",
  "justify",
  "keep",
  "key",
  "kick",
  "kid",
  "kill",
  "killer",
  "killing",
  "kind",
  "king",
  "kiss",
  "kitchen",
  "knee",
  "knife",
  "knock",
  "know",
  "knowledge",
  "lab",
  "label",
  "labor",
  "laboratory",
  "lack",
  "lady",
  "lake",
  "land",
  "landscape",
  "language",
  "lap",
  "large",
  "largely",
  "last",
  "late",
  "later",
  "latter",
  "laugh",
  "launch",
  "law",
  "lawn",
  "lawsuit",
  "lawyer",
  "lay",
  "layer",
  "lead",
  "leader",
  "leadership",
  "leading",
  "leaf",
  "league",
  "lean",
  "learn",
  "learning",
  "least",
  "leather",
  "leave",
  "left",
  "leg",
  "legacy",
  "legal",
  "legend",
  "legislation",
  "legislative",
  "legislator",
  "legitimate",
  "lemon",
  "length",
  "lens",
  "less",
  "lesson",
  "let",
  "letter",
  "level",
  "liberal",
  "library",
  "license",
  "lie",
  "life",
  "lifestyle",
  "lifetime",
  "lift",
  "light",
  "like",
  "likely",
  "limit",
  "limitation",
  "limited",
  "line",
  "link",
  "lip",
  "list",
  "listen",
  "literally",
  "literary",
  "literature",
  "little",
  "live",
  "living",
  "load",
  "loan",
  "local",
  "locate",
  "location",
  "lock",
  "long",
  "look",
  "loop",
  "loose",
  "lose",
  "loss",
  "lost",
  "lot",
  "lots",
  "loud",
  "love",
  "lovely",
  "lover",
  "low",
  "lower",
  "luck",
  "lucky",
  "lunch",
  "lung",
  "machine",
  "mad",
  "magazine",
  "magic",
  "mail",
  "main",
  "mainly",
  "maintain",
  "maintenance",
  "major",
  "majority",
  "make",
  "maker",
  "makeup",
  "male",
  "mall",
  "man",
  "manage",
  "management",
  "manager",
  "manner",
  "manufacturer",
  "manufacturing",
  "many",
  "map",
  "margin",
  "mark",
  "market",
  "marketing",
  "marriage",
  "married",
  "marry",
  "mask",
  "mass",
  "massive",
  "master",
  "match",
  "material",
  "math",
  "matter",
  "may",
  "maybe",
  "mayor",
  "me",
  "meal",
  "mean",
  "meaning",
  "meanwhile",
  "measure",
  "measurement",
  "meat",
  "mechanism",
  "media",
  "medical",
  "medication",
  "medicine",
  "medium",
  "meet",
  "meeting",
  "member",
  "membership",
  "memory",
  "mental",
  "mention",
  "menu",
  "mere",
  "merely",
  "mess",
  "message",
  "metal",
  "meter",
  "method",
  "middle",
  "might",
  "mile",
  "military",
  "milk",
  "million",
  "mind",
  "mine",
  "minister",
  "minor",
  "minority",
  "minute",
  "miracle",
  "mirror",
  "miss",
  "missile",
  "mission",
  "mistake",
  "mix",
  "mixture",
  "mm-hmm",
  "mode",
  "model",
  "moderate",
  "modern",
  "modest",
  "mom",
  "moment",
  "money",
  "monitor",
  "month",
  "mood",
  "moon",
  "moral",
  "more",
  "moreover",
  "morning",
  "mortgage",
  "most",
  "mostly",
  "mother",
  "motion",
  "motivation",
  "motor",
  "mount",
  "mountain",
  "mouse",
  "mouth",
  "move",
  "movement",
  "movie",
  "mr",
  "mrs",
  "much",
  "multiple",
  "murder",
  "muscle",
  "museum",
  "music",
  "musical",
  "musician",
  "must",
  "mutual",
  "my",
  "myself",
  "mystery",
  "myth",
  "nail",
  "name",
  "narrative",
  "narrow",
  "nation",
  "national",
  "native",
  "natural",
  "naturally",
  "nature",
  "near",
  "nearby",
  "nearly",
  "necessarily",
  "necessary",
  "neck",
  "need",
  "negative",
  "negotiate",
  "negotiation",
  "neighbor",
  "neighborhood",
  "neither",
  "nerve",
  "nervous",
  "nest",
  "net",
  "network",
  "never",
  "nevertheless",
  "new",
  "newly",
  "news",
  "newspaper",
  "next",
  "nice",
  "night",
  "nine",
  "no",
  "nobody",
  "nod",
  "noise",
  "nomination",
  "none",
  "nonetheless",
  "nor",
  "normal",
  "normally",
  "north",
  "northern",
  "nose",
  "not",
  "note",
  "nothing",
  "notice",
  "notion",
  "novel",
  "now",
  "nowhere",
  "nuclear",
  "number",
  "numerous",
  "nurse",
  "nut",
  "object",
  "objective",
  "obligation",
  "observation",
  "observe",
  "observer",
  "obtain",
  "obvious",
  "obviously",
  "occasion",
  "occasionally",
  "occur",
  "ocean",
  "odd",
  "odds",
  "of",
  "off",
  "offense",
  "offensive",
  "offer",
  "office",
  "officer",
  "official",
  "often",
  "oh",
  "oil",
  "ok",
  "okay",
  "old",
  "on",
  "once",
  "one",
  "ongoing",
  "onion",
  "online",
  "only",
  "onto",
  "open",
  "opening",
  "operate",
  "operating",
  "operation",
  "operator",
  "opinion",
  "opponent",
  "opportunity",
  "oppose",
  "opposite",
  "opposition",
  "option",
  "or",
  "orange",
  "order",
  "ordinary",
  "organic",
  "organization",
  "organize",
  "orientation",
  "origin",
  "original",
  "originally",
  "other",
  "others",
  "otherwise",
  "ought",
  "our",
  "ourselves",
  "out",
  "outcome",
  "outline",
  "outlook",
  "output",
  "outside",
  "outstanding",
  "over",
  "overall",
  "overcome",
  "overlook",
  "owe",
  "own",
  "owner",
  "pace",
  "pack",
  "package",
  "page",
  "pain",
  "painful",
  "paint",
  "painter",
  "painting",
  "pair",
  "pale",
  "pan",
  "panel",
  "pant",
  "paper",
  "parent",
  "park",
  "parking",
  "part",
  "participant",
  "participate",
  "participation",
  "particular",
  "particularly",
  "partly",
  "partner",
  "partnership",
  "party",
  "pass",
  "passage",
  "passenger",
  "passion",
  "past",
  "patch",
  "path",
  "patient",
  "pattern",
  "pause",
  "pay",
  "payment",
  "peace",
  "peak",
  "peer",
  "penalty",
  "people",
  "pepper",
  "per",
  "perceive",
  "percentage",
  "perception",
  "perfect",
  "perfectly",
  "perform",
  "performance",
  "perhaps",
  "period",
  "permanent",
  "permission",
  "permit",
  "person",
  "personal",
  "personality",
  "personally",
  "personnel",
  "perspective",
  "persuade",
  "pet",
  "phase",
  "phenomenon",
  "philosophy",
  "phone",
  "photo",
  "photograph",
  "photographer",
  "phrase",
  "physical",
  "physically",
  "physician",
  "piano",
  "pick",
  "picture",
  "pie",
  "piece",
  "pile",
  "pilot",
  "pin",
  "pink",
  "pioneer",
  "pipe",
  "pitch",
  "place",
  "plan",
  "plane",
  "planet",
  "planning",
  "plant",
  "plastic",
  "plate",
  "platform",
  "play",
  "player",
  "please",
  "pleasure",
  "plenty",
  "plot",
  "plus",
  "pm",
  "pocket",
  "poem",
  "poet",
  "poetry",
  "point",
  "pole",
  "police",
  "policy",
  "political",
  "politically",
  "politician",
  "politics",
  "poll",
  "pollution",
  "pool",
  "poor",
  "pop",
  "popular",
  "population",
  "porch",
  "port",
  "portion",
  "portrait",
  "portray",
  "pose",
  "position",
  "positive",
  "possess",
  "possibility",
  "possible",
  "possibly",
  "post",
  "pot",
  "potato",
  "potential",
  "potentially",
  "pound",
  "pour",
  "poverty",
  "powder",
  "power",
  "powerful",
  "practical",
  "practice",
  "pray",
  "prayer",
  "precisely",
  "predict",
  "prefer",
  "preference",
  "pregnancy",
  "pregnant",
  "preparation",
  "prepare",
  "presence",
  "present",
  "presentation",
  "preserve",
  "president",
  "presidential",
  "press",
  "pressure",
  "pretend",
  "pretty",
  "prevent",
  "previous",
  "previously",
  "price",
  "pride",
  "priest",
  "primarily",
  "primary",
  "prime",
  "principal",
  "principle",
  "print",
  "prior",
  "priority",
  "prison",
  "prisoner",
  "privacy",
  "private",
  "probably",
  "problem",
  "procedure",
  "proceed",
  "process",
  "produce",
  "producer",
  "product",
  "production",
  "profession",
  "professional",
  "professor",
  "profile",
  "profit",
  "program",
  "progress",
  "project",
  "prominent",
  "promise",
  "promote",
  "promotion",
  "prompt",
  "proof",
  "proper",
  "properly",
  "property",
  "proportion",
  "proposal",
  "propose",
  "proposed",
  "prosecutor",
  "prospect",
  "protect",
  "protection",
  "protein",
  "protest",
  "proud",
  "prove",
  "provide",
  "provider",
  "province",
  "provision",
  "psychological",
  "psychologist",
  "psychology",
  "public",
  "publication",
  "publicly",
  "publish",
  "publisher",
  "pull",
  "punch",
  "purchase",
  "pure",
  "purple",
  "purpose",
  "pursue",
  "push",
  "put",
  "qualify",
  "quality",
  "quarter",
  "quarterback",
  "question",
  "quick",
  "quickly",
  "quiet",
  "quietly",
  "quit",
  "quite",
  "quote",
  "race",
  "racial",
  "radical",
  "radio",
  "rail",
  "rain",
  "raise",
  "range",
  "rank",
  "rapid",
  "rapidly",
  "rare",
  "rarely",
  "rate",
  "rather",
  "rating",
  "ratio",
  "raw",
  "reach",
  "react",
  "reaction",
  "read",
  "reader",
  "reading",
  "ready",
  "real",
  "reality",
  "realize",
  "really",
  "reason",
  "reasonable",
  "reasonably",
  "recall",
  "receive",
  "recent",
  "recently",
  "recipe",
  "recognition",
  "recognize",
  "recommend",
  "recommendation",
  "record",
  "recording",
  "recover",
  "recovery",
  "recruit",
  "red",
  "reduce",
  "reduction",
  "refer",
  "reference",
  "reflect",
  "reflection",
  "reform",
  "refugee",
  "refuse",
  "regard",
  "regarding",
  "regardless",
  "regime",
  "region",
  "regional",
  "register",
  "regular",
  "regularly",
  "regulate",
  "regulation",
  "regulator",
  "regulatory",
  "reinforce",
  "reject",
  "relate",
  "relation",
  "relationship",
  "relative",
  "relatively",
  "relax",
  "release",
  "relevant",
  "reliability",
  "reliable",
  "relief",
  "religion",
  "religious",
  "reluctant",
  "rely",
  "remain",
  "remaining",
  "remarkable",
  "remember",
  "remind",
  "remote",
  "removal",
  "remove",
  "repeat",
  "repeatedly",
  "replace",
  "reply",
  "report",
  "reporter",
  "represent",
  "representation",
  "representative",
  "republican",
  "reputation",
  "request",
  "require",
  "requirement",
  "research",
  "researcher",
  "resemble",
  "reservation",
  "resident",
  "resist",
  "resistance",
  "resolution",
  "resolve",
  "resort",
  "resource",
  "respect",
  "respond",
  "respondent",
  "response",
  "responsibility",
  "responsible",
  "rest",
  "restaurant",
  "restore",
  "restriction",
  "result",
  "retain",
  "retire",
  "retirement",
  "return",
  "reveal",
  "revenue",
  "review",
  "revolution",
  "rhythm",
  "rice",
  "rich",
  "rid",
  "ride",
  "rifle",
  "right",
  "ring",
  "rise",
  "risk",
  "river",
  "road",
  "rock",
  "role",
  "roll",
  "romantic",
  "roof",
  "room",
  "root",
  "rope",
  "rose",
  "rough",
  "roughly",
  "round",
  "route",
  "routine",
  "row",
  "rub",
  "rule",
  "run",
  "running",
  "rural",
  "rush",
  "sad",
  "safe",
  "safety",
  "sake",
  "salad",
  "salary",
  "sale",
  "sales",
  "salt",
  "same",
  "sample",
  "sanction",
  "sand",
  "satellite",
  "satisfaction",
  "satisfy",
  "sauce",
  "save",
  "saving",
  "saw",
  "say",
  "scale",
  "scandal",
  "scared",
  "scenario",
  "scene",
  "schedule",
  "scheme",
  "scholar",
  "scholarship",
  "school",
  "science",
  "scientific",
  "scientist",
  "scope",
  "score",
  "scream",
  "screen",
  "script",
  "sea",
  "search",
  "season",
  "seat",
  "second",
  "secret",
  "secretary",
  "section",
  "sector",
  "secure",
  "security",
  "see",
  "seed",
  "seek",
  "seem",
  "segment",
  "seize",
  "select",
  "selection",
  "self",
  "sell",
  "senate",
  "senator",
  "send",
  "senior",
  "sense",
  "sensitive",
  "sentence",
  "separate",
  "sequence",
  "series",
  "serious",
  "seriously",
  "serve",
  "service",
  "session",
  "set",
  "setting",
  "settle",
  "settlement",
  "seven",
  "several",
  "severe",
  "sex",
  "sexual",
  "shade",
  "shadow",
  "shake",
  "shall",
  "shape",
  "share",
  "sharp",
  "she",
  "sheet",
  "shelf",
  "shell",
  "shelter",
  "shift",
  "shine",
  "ship",
  "shirt",
  "shit",
  "shock",
  "shoe",
  "shoot",
  "shooting",
  "shop",
  "shopping",
  "shore",
  "short",
  "shortly",
  "shot",
  "should",
  "shoulder",
  "shout",
  "show",
  "shower",
  "shrug",
  "shut",
  "sick",
  "side",
  "sigh",
  "sight",
  "sign",
  "signal",
  "significance",
  "significant",
  "significantly",
  "silence",
  "silent",
  "silly",
  "silver",
  "similar",
  "similarly",
  "simple",
  "simply",
  "sin",
  "since",
  "sing",
  "singer",
  "single",
  "sink",
  "sir",
  "sister",
  "sit",
  "site",
  "situation",
  "six",
  "size",
  "ski",
  "skill",
  "skin",
  "sky",
  "slave",
  "sleep",
  "slice",
  "slide",
  "slight",
  "slightly",
  "slow",
  "slowly",
  "small",
  "smart",
  "smell",
  "smile",
  "smoke",
  "smooth",
  "snap",
  "snow",
  "so",
  "so-called",
  "soccer",
  "social",
  "society",
  "soft",
  "software",
  "soil",
  "solar",
  "soldier",
  "solid",
  "solution",
  "solve",
  "some",
  "somebody",
  "somehow",
  "someone",
  "something",
  "sometimes",
  "somewhat",
  "somewhere",
  "son",
  "song",
  "soon",
  "sophisticated",
  "sorry",
  "sort",
  "soul",
  "sound",
  "soup",
  "source",
  "south",
  "southern",
  "space",
  "spare",
  "speak",
  "speaker",
  "special",
  "specialist",
  "species",
  "specific",
  "specifically",
  "speech",
  "speed",
  "spend",
  "spending",
  "spin",
  "spirit",
  "spiritual",
  "split",
  "spokesman",
  "sport",
  "spot",
  "spread",
  "spring",
  "square",
  "squeeze",
  "stability",
  "stable",
  "staff",
  "stage",
  "stake",
  "stand",
  "standard",
  "standing",
  "star",
  "stare",
  "start",
  "state",
  "statement",
  "station",
  "statistics",
  "status",
  "stay",
  "steady",
  "steal",
  "steel",
  "step",
  "stick",
  "still",
  "stir",
  "stock",
  "stomach",
  "stone",
  "stop",
  "storage",
  "store",
  "storm",
  "story",
  "straight",
  "strange",
  "stranger",
  "strategic",
  "strategy",
  "stream",
  "street",
  "strength",
  "strengthen",
  "stress",
  "stretch",
  "strike",
  "string",
  "strip",
  "stroke",
  "strong",
  "strongly",
  "structure",
  "struggle",
  "student",
  "studio",
  "study",
  "stuff",
  "stupid",
  "style",
  "subject",
  "submit",
  "subsequent",
  "substance",
  "substantial",
  "succeed",
  "success",
  "successful",
  "successfully",
  "such",
  "sudden",
  "suddenly",
  "sue",
  "suffer",
  "sufficient",
  "sugar",
  "suggest",
  "suggestion",
  "suicide",
  "suit",
  "summer",
  "summit",
  "sun",
  "super",
  "supply",
  "support",
  "supporter",
  "suppose",
  "supposed",
  "supreme",
  "sure",
  "surely",
  "surface",
  "surgery",
  "surprise",
  "surprised",
  "surprising",
  "surprisingly",
  "surround",
  "survey",
  "survival",
  "survive",
  "survivor",
  "suspect",
  "sustain",
  "swear",
  "sweep",
  "sweet",
  "swim",
  "swing",
  "switch",
  "symbol",
  "symptom",
  "syndrome",
  "system",
  "table",
  "tackle",
  "tactic",
  "tail",
  "take",
  "tale",
  "talent",
  "talk",
  "tall",
  "tank",
  "tap",
  "tape",
  "target",
  "task",
  "taste",
  "tax",
  "taxpayer",
  "tea",
  "teach",
  "teacher",
  "teaching",
  "team",
  "tear",
  "teaspoon",
  "technical",
  "technique",
  "technology",
  "teen",
  "teenager",
  "telephone",
  "telescope",
  "television",
  "tell",
  "temperature",
  "temporary",
  "ten",
  "tend",
  "tendency",
  "tennis",
  "tension",
  "tent",
  "term",
  "terms",
  "terrible",
  "territory",
  "terror",
  "terrorism",
  "terrorist",
  "test",
  "testify",
  "testimony",
  "testing",
  "text",
  "than",
  "thank",
  "thanks",
  "that",
  "the",
  "theater",
  "their",
  "them",
  "theme",
  "themselves",
  "then",
  "theory",
  "therapy",
  "there",
  "therefore",
  "these",
  "they",
  "thick",
  "thin",
  "thing",
  "think",
  "thinking",
  "third",
  "thirty",
  "this",
  "those",
  "though",
  "thought",
  "thousand",
  "threat",
  "threaten",
  "three",
  "throat",
  "through",
  "throughout",
  "throw",
  "thumb",
  "thus",
  "ticket",
  "tie",
  "tight",
  "time",
  "tiny",
  "tip",
  "tire",
  "tired",
  "tissue",
  "title",
  "to",
  "tobacco",
  "today",
  "toe",
  "together",
  "tomato",
  "tomorrow",
  "tone",
  "tongue",
  "tonight",
  "too",
  "tool",
  "tooth",
  "top",
  "topic",
  "toss",
  "total",
  "totally",
  "touch",
  "tough",
  "tour",
  "tourist",
  "tournament",
  "toward",
  "towards",
  "tower",
  "town",
  "toy",
  "trace",
  "track",
  "trade",
  "tradition",
  "traditional",
  "traffic",
  "tragedy",
  "trail",
  "train",
  "training",
  "transfer",
  "transform",
  "transformation",
  "transition",
  "translate",
  "transportation",
  "trap",
  "trash",
  "travel",
  "treat",
  "treatment",
  "treaty",
  "tree",
  "tremendous",
  "trend",
  "trial",
  "tribe",
  "trick",
  "trip",
  "troop",
  "trouble",
  "truck",
  "true",
  "truly",
  "trust",
  "truth",
  "try",
  "tube",
  "tunnel",
  "turn",
  "tv",
  "twelve",
  "twenty",
  "twice",
  "twin",
  "two",
  "type",
  "typical",
  "typically",
  "ugly",
  "ultimate",
  "ultimately",
  "unable",
  "uncle",
  "under",
  "undergo",
  "understand",
  "understanding",
  "unfortunately",
  "union",
  "unique",
  "unit",
  "united",
  "universal",
  "universe",
  "university",
  "unknown",
  "unless",
  "unlike",
  "unlikely",
  "until",
  "unusual",
  "up",
  "upon",
  "upper",
  "urban",
  "urge",
  "us",
  "use",
  "used",
  "useful",
  "user",
  "usual",
  "usually",
  "utility",
  "utilize",
  "vacation",
  "valley",
  "valuable",
  "value",
  "variable",
  "variation",
  "variety",
  "various",
  "vast",
  "vegetable",
  "vehicle",
  "venture",
  "version",
  "versus",
  "very",
  "vessel",
  "veteran",
  "via",
  "victim",
  "victory",
  "video",
  "view",
  "viewer",
  "village",
  "violence",
  "violent",
  "virtually",
  "virtue",
  "virus",
  "visible",
  "vision",
  "visit",
  "visitor",
  "visual",
  "vital",
  "voice",
  "volume",
  "volunteer",
  "vote",
  "voter",
  "vs",
  "vulnerable",
  "wage",
  "wait",
  "wake",
  "walk",
  "wall",
  "wander",
  "want",
  "war",
  "ward",
  "warm",
  "warn",
  "warning",
  "wash",
  "waste",
  "watch",
  "water",
  "wave",
  "way",
  "we",
  "weak",
  "wealth",
  "weapon",
  "wear",
  "weather",
  "weave",
  "web",
  "wedding",
  "week",
  "weekend",
  "weekly",
  "weigh",
  "weight",
  "welcome",
  "welfare",
  "well",
  "west",
  "western",
  "wet",
  "what",
  "whatever",
  "wheel",
  "when",
  "whenever",
  "where",
  "whereas",
  "whether",
  "which",
  "while",
  "whisper",
  "white",
  "who",
  "whole",
  "whom",
  "whose",
  "why",
  "wide",
  "widely",
  "wife",
  "wild",
  "will",
  "willing",
  "win",
  "wind",
  "window",
  "wine",
  "wing",
  "winner",
  "winter",
  "wipe",
  "wire",
  "wisdom",
  "wise",
  "wish",
  "with",
  "withdraw",
  "within",
  "without",
  "witness",
  "woman",
  "wonder",
  "wonderful",
  "wood",
  "wooden",
  "word",
  "work",
  "worker",
  "working",
  "workshop",
  "world",
  "worried",
  "worry",
  "worth",
  "would",
  "wound",
  "wrap",
  "write",
  "writer",
  "writing",
  "wrong",
  "yard",
  "yeah",
  "year",
  "yell",
  "yellow",
  "yes",
  "yesterday",
  "yet",
  "yield",
  "you",
  "young",
  "your",
  "yours",
  "yourself",
  "youth",
  "zone"
]);
const KEYBOARD_ADJACENT = {
  "a": ["q", "w", "s", "z"],
  "b": ["v", "g", "h", "n"],
  "c": ["x", "d", "f", "v"],
  "d": ["s", "e", "r", "f", "c", "x"],
  "e": ["w", "s", "d", "r"],
  "f": ["d", "r", "t", "g", "v", "c"],
  "g": ["f", "t", "y", "h", "b", "v"],
  "h": ["g", "y", "u", "j", "n", "b"],
  "i": ["u", "j", "k", "o"],
  "j": ["h", "u", "i", "k", "m", "n"],
  "k": ["j", "i", "o", "l", "m"],
  "l": ["k", "o", "p"],
  "m": ["n", "j", "k"],
  "n": ["b", "h", "j", "m"],
  "o": ["i", "k", "l", "p"],
  "p": ["o", "l"],
  "q": ["w", "a"],
  "r": ["e", "d", "f", "t"],
  "s": ["a", "w", "e", "d", "z", "x"],
  "t": ["r", "f", "g", "y"],
  "u": ["y", "h", "j", "i"],
  "v": ["c", "f", "g", "b"],
  "w": ["q", "a", "s", "e"],
  "x": ["z", "s", "d", "c"],
  "y": ["t", "g", "h", "u"],
  "z": ["a", "s", "x"]
};
function levenshteinDistance(a, b) {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          // substitution
          matrix[i][j - 1] + 1,
          // insertion
          matrix[i - 1][j] + 1
          // deletion
        );
      }
    }
  }
  return matrix[b.length][a.length];
}
function isAdjacentKeyTypo(word, candidate) {
  if (word.length !== candidate.length) return false;
  let diffCount = 0;
  for (let i = 0; i < word.length; i++) {
    if (word[i] !== candidate[i]) {
      diffCount++;
      if (diffCount > 1) return false;
      const adjacent = KEYBOARD_ADJACENT[word[i].toLowerCase()] || [];
      if (!adjacent.includes(candidate[i].toLowerCase())) {
        return false;
      }
    }
  }
  return diffCount === 1;
}
function getSuggestions(word, dictionary, maxSuggestions = 5) {
  const lowerWord = word.toLowerCase();
  const candidates = [];
  for (const dictWord of dictionary) {
    if (Math.abs(dictWord.length - lowerWord.length) > 2) continue;
    const distance = levenshteinDistance(lowerWord, dictWord);
    if (distance <= 2) {
      const isAdjacent = isAdjacentKeyTypo(lowerWord, dictWord);
      const score = isAdjacent ? distance - 0.5 : distance;
      candidates.push({ word: dictWord, score });
    }
  }
  candidates.sort((a, b) => a.score - b.score);
  return candidates.slice(0, maxSuggestions).map((c) => {
    if (word[0] === word[0].toUpperCase()) {
      return c.word.charAt(0).toUpperCase() + c.word.slice(1);
    }
    return c.word;
  });
}
function isWordCorrect(word, customDictionary) {
  const lowerWord = word.toLowerCase();
  if (ENGLISH_WORDS.has(lowerWord)) return true;
  if (customDictionary.has(lowerWord)) return true;
  if (word === word.toUpperCase() && word.length <= 5) return true;
  if (/^\d+$/.test(word)) return true;
  if (/^[a-z]+\d+$/i.test(word)) return true;
  return false;
}
function extractWords(text) {
  const words = [];
  const regex = /[a-zA-Z']+/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    const word = match[0];
    if (word.length === 1 && word.toLowerCase() !== "i" && word.toLowerCase() !== "a") {
      continue;
    }
    if (word.replace(/'/g, "").length === 0) continue;
    words.push({
      word,
      start: match.index,
      end: match.index + word.length
    });
  }
  return words;
}
function findMisspellings(text, customDictionary = /* @__PURE__ */ new Set()) {
  const words = extractWords(text);
  const misspellings = [];
  const fullDictionary = /* @__PURE__ */ new Set([...ENGLISH_WORDS, ...customDictionary]);
  for (const { word, start, end } of words) {
    if (!isWordCorrect(word, customDictionary)) {
      const suggestions = getSuggestions(word, fullDictionary);
      misspellings.push({
        word,
        startIndex: start,
        endIndex: end,
        suggestions
      });
    }
  }
  return misspellings;
}
const GRAMMAR_RULES = [
  // Their/There/They're
  {
    pattern: /\b(their|there|they're)\b/gi,
    check: (match, context) => {
      const word = match[0];
      const lower = word.toLowerCase();
      const index = match.index;
      context.substring(Math.max(0, index - 20), index).toLowerCase();
      const after = context.substring(index + word.length, index + word.length + 20).toLowerCase();
      if (lower === "there" && /(is|are|was|were|will|can|should)\s/.test(after)) {
        return null;
      }
      if (lower === "they're" || lower === "theyre") {
        return null;
      }
      if (lower === "their" && /(house|car|name|book|idea|way|own|best|first|last|new|old)\b/i.test(after)) {
        return null;
      }
      return null;
    }
  },
  // Your/You're
  {
    pattern: /\b(your|you're|youre)\b/gi,
    check: (match, context) => {
      const word = match[0];
      const lower = word.toLowerCase();
      const index = match.index;
      const after = context.substring(index + word.length, index + word.length + 10).toLowerCase();
      if ((lower === "your" || lower === "youre") && /^(going|doing|sure|right|wrong|here|there|welcome|ready)/.test(after)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "you're",
          rule: "Use 'you're' (you are) before verbs/adjectives"
        };
      }
      if (lower === "you're" && /^(name|book|car|house|idea|way|best|first|last|new|old)\b/.test(after)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "your",
          rule: "Use 'your' (possessive) before nouns"
        };
      }
      return null;
    }
  },
  // Its/It's
  {
    pattern: /\b(its|it's)\b/gi,
    check: (match, context) => {
      const word = match[0];
      const lower = word.toLowerCase();
      const index = match.index;
      const after = context.substring(index + word.length, index + word.length + 10).toLowerCase();
      if (lower === "its" && /^(going|doing|not|is|was|will|can|should|has|had|been|being)\b/.test(after)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "it's",
          rule: "Use 'it's' (it is) before verbs"
        };
      }
      if (lower === "it's" && /^(name|book|car|house|idea|way|best|first|last|new|old|own)\b/.test(after)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "its",
          rule: "Use 'its' (possessive) before nouns"
        };
      }
      return null;
    }
  },
  // To/Too/Two
  {
    pattern: /\b(to|too|two)\b/gi,
    check: (match, context) => {
      const word = match[0];
      const lower = word.toLowerCase();
      const index = match.index;
      const before = context.substring(Math.max(0, index - 10), index).toLowerCase();
      const after = context.substring(index + word.length, index + word.length + 10).toLowerCase();
      if (lower === "to" && (/^(also|much|many|big|small|fast|slow)\b/.test(after) || /(,|;)\s*to\s+also/.test(before + word + after))) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "too",
          rule: "Use 'too' for 'also' or 'excessive'"
        };
      }
      if (lower === "to" && /^(people|men|women|children|things|items|days|weeks|years|hours|minutes|seconds)\b/.test(after)) {
        return null;
      }
      return null;
    }
  },
  // Then/Than
  {
    pattern: /\b(then|than)\b/gi,
    check: (match, context) => {
      const word = match[0];
      const lower = word.toLowerCase();
      const index = match.index;
      const before = context.substring(Math.max(0, index - 10), index).toLowerCase();
      if (lower === "then" && /(more|less|better|worse|bigger|smaller|faster|slower|older|younger|taller|shorter)\s+then\b/.test(before + word)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "than",
          rule: "Use 'than' for comparisons"
        };
      }
      if (lower === "than" && /(if|when|after|before|first|next|now)\s+than\b/.test(before + word)) {
        return {
          word,
          startIndex: index,
          endIndex: index + word.length,
          suggestion: "then",
          rule: "Use 'then' for time sequence"
        };
      }
      return null;
    }
  }
];
function findGrammarErrors(text) {
  const errors = [];
  for (const rule of GRAMMAR_RULES) {
    const matches = Array.from(text.matchAll(rule.pattern));
    for (const match of matches) {
      const error = rule.check(match, text);
      if (error) {
        errors.push(error);
      }
    }
  }
  return errors;
}
function grammarErrorToMisspelling(error) {
  return {
    word: error.word,
    startIndex: error.startIndex,
    endIndex: error.endIndex,
    suggestions: [error.suggestion]
  };
}
async function getStatistics() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.STATISTICS);
  return { ...DEFAULT_STATISTICS, ...result[STORAGE_KEYS.STATISTICS] };
}
async function updateStatistics(updates) {
  const current = await getStatistics();
  const updated = { ...current, ...updates };
  await chrome.storage.sync.set({ [STORAGE_KEYS.STATISTICS]: updated });
  return updated;
}
async function incrementWordsChecked(count = 1) {
  const stats = await getStatistics();
  await updateStatistics({ wordsChecked: stats.wordsChecked + count });
}
async function incrementMisspellingsFound(count = 1) {
  const stats = await getStatistics();
  await updateStatistics({ misspellingsFound: stats.misspellingsFound + count });
}
async function incrementCorrectionsMade(count = 1) {
  const stats = await getStatistics();
  await updateStatistics({ correctionsMade: stats.correctionsMade + count });
}
async function incrementWordsAdded(count = 1) {
  const stats = await getStatistics();
  await updateStatistics({ wordsAdded: stats.wordsAdded + count });
}
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
let shortcuts = [];
function registerShortcut(shortcut) {
  shortcuts.push(shortcut);
}
function handleKeyboardEvent(event) {
  const target = event.target;
  target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target.isContentEditable;
  for (const shortcut of shortcuts) {
    const keyMatch = event.key.toLowerCase() === shortcut.key.toLowerCase() || event.code.toLowerCase() === shortcut.key.toLowerCase();
    const ctrlMatch = shortcut.ctrl === void 0 ? true : event.ctrlKey === shortcut.ctrl;
    const shiftMatch = shortcut.shift === void 0 ? true : event.shiftKey === shortcut.shift;
    const altMatch = shortcut.alt === void 0 ? true : event.altKey === shortcut.alt;
    const metaMatch = shortcut.meta === void 0 ? true : event.metaKey === shortcut.meta;
    if (keyMatch && ctrlMatch && shiftMatch && altMatch && metaMatch) {
      if (shortcut.ctrl || shortcut.shift || shortcut.alt || shortcut.meta) {
        event.preventDefault();
        event.stopPropagation();
      }
      shortcut.action();
      return true;
    }
  }
  return false;
}
async function setupSpellCheckShortcuts() {
  const settings = await getGlobalSettings();
  registerShortcut({
    key: "s",
    ctrl: true,
    shift: true,
    action: async () => {
      const hostname = window.location.hostname;
      const { getSiteSettings, setSiteSettings } = await __vitePreload(async () => {
        const { getSiteSettings: getSiteSettings2, setSiteSettings: setSiteSettings2 } = await import("./assets/storage-BuTDZeqy.js").then((n) => n.k);
        return { getSiteSettings: getSiteSettings2, setSiteSettings: setSiteSettings2 };
      }, true ? [] : void 0);
      const siteSettings2 = await getSiteSettings(hostname);
      await setSiteSettings(hostname, { enabled: !siteSettings2.enabled });
      showNotification(siteSettings2.enabled ? "Spell checking disabled" : "Spell checking enabled");
    }
  });
  registerShortcut({
    key: "u",
    ctrl: true,
    shift: true,
    action: async () => {
      const { setGlobalSettings } = await __vitePreload(async () => {
        const { setGlobalSettings: setGlobalSettings2 } = await import("./assets/storage-BuTDZeqy.js").then((n) => n.k);
        return { setGlobalSettings: setGlobalSettings2 };
      }, true ? [] : void 0);
      await setGlobalSettings({ showUnderlines: !settings.showUnderlines });
      showNotification(settings.showUnderlines ? "Underlines hidden" : "Underlines shown");
    }
  });
}
function showNotification(message) {
  try {
    const { showToast: showToast2 } = require("./toast");
    showToast2(`FSA: ${message}`, "info", 2e3);
  } catch {
    const notification = document.createElement("div");
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #1a1a1a;
      color: #fafafa;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 14px;
      border: 1px solid #2a2a2a;
    `;
    notification.textContent = `FSA: ${message}`;
    document.body.appendChild(notification);
    setTimeout(() => {
      notification.style.opacity = "0";
      notification.style.transition = "opacity 0.3s";
      setTimeout(() => notification.remove(), 300);
    }, 2e3);
  }
}
let toastContainer = null;
function initToastContainer() {
  if (toastContainer) return;
  toastContainer = document.createElement("div");
  toastContainer.id = "fsa-toast-container";
  toastContainer.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 2147483647;
    display: flex;
    flex-direction: column;
    gap: 12px;
    pointer-events: none;
  `;
  document.body.appendChild(toastContainer);
}
function showToast(message, type = "info", duration = 3e3) {
  initToastContainer();
  if (!toastContainer) return;
  const toast = document.createElement("div");
  toast.className = `fsa-toast fsa-toast-${type}`;
  toast.style.cssText = `
    background: #1a1a1a;
    border: 1px solid #333;
    border-left: 3px solid ${type === "success" ? "#22c55e" : type === "error" ? "#ef4444" : "#f97316"};
    border-radius: 8px;
    padding: 12px 16px;
    color: #fafafa;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    pointer-events: auto;
    animation: fsa-toast-slide-in 0.2s ease-out;
    max-width: 300px;
  `;
  toast.textContent = message;
  toast.setAttribute("role", "alert");
  toast.setAttribute("aria-live", "polite");
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = "fsa-toast-slide-out 0.2s ease-out";
    setTimeout(() => {
      toast.remove();
    }, 200);
  }, duration);
}
const style = document.createElement("style");
style.textContent = `
  @keyframes fsa-toast-slide-in {
    from {
      opacity: 0;
      transform: translateX(100%);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  @keyframes fsa-toast-slide-out {
    from {
      opacity: 1;
      transform: translateX(0);
    }
    to {
      opacity: 0;
      transform: translateX(100%);
    }
  }
`;
document.head.appendChild(style);
const DEBOUNCE_MS = 500;
const CONTEXT_MENU_ID = "fsa-context-menu";
const HIGHLIGHT_CONTAINER_CLASS = "fsa-highlight-container";
let globalSettings = DEFAULT_GLOBAL_SETTINGS;
let siteSettings = DEFAULT_SITE_SETTINGS;
let customDictionaryWords = /* @__PURE__ */ new Set();
const fieldStates = /* @__PURE__ */ new Map();
let activeContextMenu = null;
let ignoredWords = /* @__PURE__ */ new Set();
async function initialize() {
  console.log("FSA: Content script initializing on", window.location.hostname);
  try {
    await loadSettings();
    await loadCustomDictionary();
    console.log("FSA: Settings loaded", {
      globalEnabled: globalSettings.enabled,
      siteEnabled: siteSettings.enabled,
      showUnderlines: globalSettings.showUnderlines,
      hostname: window.location.hostname
    });
    if (!isEnabled()) {
      console.log("FSA: Disabled for this site - check popup to enable");
      console.log("FSA: Global enabled:", globalSettings.enabled, "Site enabled:", siteSettings.enabled);
      return;
    }
    setupMutationObserver();
    setupEventListeners();
    setupKeyboardShortcuts();
    scanForEditableFields();
    const fieldCount = fieldStates.size;
    console.log(`FSA: Content script initialized - found ${fieldCount} editable field(s)`);
    if (fieldCount === 0) {
      console.log("FSA: No fields found initially, will retry in 1s, 3s, and 5s...");
      setTimeout(() => {
        scanForEditableFields();
        console.log(`FSA: Re-scan 1s - found ${fieldStates.size} editable field(s)`);
      }, 1e3);
      setTimeout(() => {
        scanForEditableFields();
        console.log(`FSA: Re-scan 3s - found ${fieldStates.size} editable field(s)`);
      }, 3e3);
      setTimeout(() => {
        scanForEditableFields();
        console.log(`FSA: Re-scan 5s - found ${fieldStates.size} editable field(s)`);
      }, 5e3);
    }
  } catch (error) {
    console.error("FSA: Initialization error:", error);
  }
}
async function setupKeyboardShortcuts() {
  await setupSpellCheckShortcuts();
  document.addEventListener("keydown", (event) => {
    handleKeyboardEvent(event);
  }, true);
}
function isEnabled() {
  return globalSettings.enabled && siteSettings.enabled;
}
async function loadSettings() {
  try {
    const globalResult = await chrome.storage.sync.get(STORAGE_KEYS.GLOBAL_SETTINGS);
    globalSettings = { ...DEFAULT_GLOBAL_SETTINGS, ...globalResult[STORAGE_KEYS.GLOBAL_SETTINGS] };
    const hostname = window.location.hostname;
    const siteKey = `${STORAGE_KEYS.SITE_SETTINGS_PREFIX}${hostname}`;
    const siteResult = await chrome.storage.sync.get(siteKey);
    siteSettings = { ...DEFAULT_SITE_SETTINGS, ...siteResult[siteKey] };
    if (matchesDisabledPattern(hostname, globalSettings.disabledPatterns)) {
      siteSettings.enabled = false;
    }
  } catch (error) {
    console.error("FSA: Error loading settings:", error);
  }
}
async function loadCustomDictionary() {
  try {
    const result = await chrome.storage.sync.get(STORAGE_KEYS.CUSTOM_DICTIONARY);
    const entries = result[STORAGE_KEYS.CUSTOM_DICTIONARY] || [];
    customDictionaryWords = new Set(entries.map((e) => e.word.toLowerCase()));
  } catch (error) {
    console.error("FSA: Error loading dictionary:", error);
  }
}
function matchesDisabledPattern(hostname, patterns) {
  return patterns.some((pattern) => {
    const regexPattern = pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
    const regex = new RegExp(`^${regexPattern}$`, "i");
    return regex.test(hostname);
  });
}
function isEditableField(element) {
  if (element instanceof HTMLInputElement) {
    const type = element.type.toLowerCase();
    if (!["text", "search", "email", "url"].includes(type)) {
      return false;
    }
  } else if (element instanceof HTMLTextAreaElement) ;
  else if (element.isContentEditable) ;
  else {
    return false;
  }
  if (isSensitiveField(element)) {
    return false;
  }
  return true;
}
function isSensitiveField(element) {
  var _a, _b, _c, _d;
  if (element instanceof HTMLInputElement) {
    const type = element.type.toLowerCase();
    if (["password", "hidden"].includes(type)) return true;
  }
  const autocomplete = ((_a = element.getAttribute("autocomplete")) == null ? void 0 : _a.toLowerCase()) || "";
  const sensitiveAutocomplete = [
    "off",
    "new-password",
    "current-password",
    "cc-",
    "credit-card",
    "card-number",
    "cvv",
    "cvc",
    "expiry",
    "security-code"
  ];
  if (sensitiveAutocomplete.some((s) => autocomplete.includes(s))) {
    return true;
  }
  const name = ((_b = element.getAttribute("name")) == null ? void 0 : _b.toLowerCase()) || "";
  const id = ((_c = element.id) == null ? void 0 : _c.toLowerCase()) || "";
  const placeholder = ((_d = element.getAttribute("placeholder")) == null ? void 0 : _d.toLowerCase()) || "";
  const combined = `${name} ${id} ${placeholder}`;
  const sensitivePatterns = [
    "password",
    "passwd",
    "pwd",
    "secret",
    "credit",
    "card",
    "cvv",
    "cvc",
    "ccv",
    "expir",
    "ssn",
    "social",
    "security",
    "pin",
    "token",
    "auth"
  ];
  if (sensitivePatterns.some((p) => combined.includes(p))) {
    return true;
  }
  return false;
}
function scanForEditableFields() {
  const inputs = document.querySelectorAll('input[type="text"], input[type="search"], input[type="email"], input[type="url"], input:not([type]), textarea');
  inputs.forEach((el) => {
    if (el instanceof HTMLElement && isEditableField(el)) {
      attachToField(el);
    }
  });
  const contentEditables = document.querySelectorAll('[contenteditable="true"], [contenteditable=""], [contenteditable]');
  contentEditables.forEach((el) => {
    if (el instanceof HTMLElement && isEditableField(el)) {
      attachToField(el);
    }
  });
  const editorSelectors = [
    '[role="textbox"]',
    "[data-placeholder]",
    ".notion-page-content",
    ".ql-editor",
    // Quill editor
    ".ProseMirror",
    // ProseMirror (used by many editors)
    "[data-slate-editor]",
    // Slate editor
    ".DraftEditor-root"
    // Draft.js
  ];
  editorSelectors.forEach((selector) => {
    try {
      const editors = document.querySelectorAll(selector);
      editors.forEach((el) => {
        if (el instanceof HTMLElement && (el.isContentEditable || el.querySelector("[contenteditable]"))) {
          if (isEditableField(el)) {
            attachToField(el);
          }
        }
      });
    } catch (e) {
    }
  });
  scanShadowDOM(document.body);
  scanIframes();
}
function scanShadowDOM(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node;
  while (node = walker.nextNode()) {
    const element = node;
    if (element.shadowRoot) {
      const shadowInputs = element.shadowRoot.querySelectorAll('input, textarea, [contenteditable="true"]');
      shadowInputs.forEach((el) => {
        if (el instanceof HTMLElement && isEditableField(el)) {
          attachToField(el);
        }
      });
      scanShadowDOM(element.shadowRoot);
    }
    if (element instanceof HTMLElement) {
      if (isEditableField(element)) {
        attachToField(element);
      }
    }
  }
}
function scanIframes() {
  const iframes = document.querySelectorAll("iframe");
  iframes.forEach((iframe) => {
    var _a;
    try {
      const iframeDoc = iframe.contentDocument || ((_a = iframe.contentWindow) == null ? void 0 : _a.document);
      if (iframeDoc) {
        const inputs = iframeDoc.querySelectorAll('input, textarea, [contenteditable="true"]');
        inputs.forEach((el) => {
          if (el instanceof HTMLElement && isEditableField(el)) {
            attachToField(el);
          }
        });
        scanShadowDOM(iframeDoc.body);
      }
    } catch (e) {
    }
  });
}
function attachToField(element) {
  if (fieldStates.has(element)) return;
  console.log("FSA: Attaching to field", element.tagName, element.className || element.id || "unnamed");
  const state = {
    element,
    lastText: "",
    misspellings: []
  };
  fieldStates.set(element, state);
  element.addEventListener("input", handleInput);
  element.addEventListener("focus", handleFocus);
  element.addEventListener("blur", handleBlur);
  element.addEventListener("scroll", handleScroll);
  const text = getFieldText(element);
  if (text.trim()) {
    scheduleSpellCheck(state);
  }
}
function detachFromField(element) {
  const state = fieldStates.get(element);
  if (!state) return;
  if (state.debounceTimer) {
    clearTimeout(state.debounceTimer);
  }
  if (state.container) {
    state.container.remove();
  }
  element.removeEventListener("input", handleInput);
  element.removeEventListener("focus", handleFocus);
  element.removeEventListener("blur", handleBlur);
  element.removeEventListener("scroll", handleScroll);
  fieldStates.delete(element);
}
function handleInput(event) {
  const element = event.target;
  const state = fieldStates.get(element);
  if (!state) return;
  if (globalSettings.autoCorrect && state.misspellings.length > 0) {
    const text = getFieldText(element);
    const lastChar = text[text.length - 1];
    if (lastChar === " " || lastChar === "\n") {
      const cursorPos = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.selectionStart || text.length : text.length;
      for (const misspelling of state.misspellings) {
        if (misspelling.endIndex <= cursorPos && misspelling.endIndex >= cursorPos - 5) {
          if (misspelling.suggestions.length > 0) {
            const suggestion = misspelling.suggestions[0];
            if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
              const newText = text.substring(0, misspelling.startIndex) + suggestion + text.substring(misspelling.endIndex);
              element.value = newText;
              element.setSelectionRange(misspelling.startIndex + suggestion.length, misspelling.startIndex + suggestion.length);
              element.dispatchEvent(new Event("input", { bubbles: true }));
              incrementCorrectionsMade(1).catch(() => {
              });
            }
            break;
          }
        }
      }
    }
  }
  scheduleSpellCheck(state);
}
function handleFocus(event) {
  const element = event.target;
  const state = fieldStates.get(element);
  if (!state) return;
  scheduleSpellCheck(state);
}
function handleBlur(_event) {
}
function handleScroll(event) {
  const element = event.target;
  const state = fieldStates.get(element);
  if (!state || !state.container) return;
  if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
    updateHighlightPositions(state);
  }
}
function scheduleSpellCheck(state) {
  if (state.debounceTimer) {
    clearTimeout(state.debounceTimer);
  }
  state.debounceTimer = setTimeout(() => {
    performSpellCheck(state).catch(() => {
    });
  }, DEBOUNCE_MS);
}
function getFieldText(element) {
  if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
    return element.value;
  }
  return element.innerText || element.textContent || "";
}
async function performSpellCheck(state) {
  if (!isEnabled()) {
    clearHighlights(state);
    return;
  }
  if (!globalSettings.showUnderlines) {
    clearHighlights(state);
    return;
  }
  const text = getFieldText(state.element);
  if (text === state.lastText) return;
  state.lastText = text;
  const wordCount = text.split(/\s+/).filter((w) => w.length > 0).length;
  if (wordCount > 0) {
    incrementWordsChecked(wordCount).catch(() => {
    });
  }
  const allMisspellings = findMisspellings(text, customDictionaryWords);
  if (globalSettings.grammarCheck) {
    const grammarErrors = findGrammarErrors(text);
    for (const error of grammarErrors) {
      allMisspellings.push(grammarErrorToMisspelling(error));
    }
  }
  state.misspellings = allMisspellings.filter(
    (m) => !ignoredWords.has(m.word.toLowerCase())
  );
  if (state.misspellings.length > 0) {
    console.log("FSA: Found misspellings:", state.misspellings.map((m) => m.word));
  }
  if (state.misspellings.length > 0) {
    incrementMisspellingsFound(state.misspellings.length).catch(() => {
    });
  }
  updateHighlights(state);
}
function clearHighlights(state) {
  if (state.container) {
    state.container.innerHTML = "";
  }
}
function updateHighlights(state) {
  if (!state.misspellings.length) {
    clearHighlights(state);
    if (state.container) {
      state.container.remove();
      state.container = void 0;
    }
    return;
  }
  if (state.element.isContentEditable) {
    updateContentEditableHighlights(state);
  } else {
    updateInputHighlights(state);
  }
}
function updateContentEditableHighlights(state) {
  if (!state.container) {
    state.container = document.createElement("div");
    state.container.className = HIGHLIGHT_CONTAINER_CLASS;
    document.body.appendChild(state.container);
  }
  state.container.innerHTML = "";
  const rect = state.element.getBoundingClientRect();
  state.container.style.cssText = `
    position: fixed;
    left: ${rect.left}px;
    top: ${rect.top}px;
    width: ${rect.width}px;
    height: ${rect.height}px;
    pointer-events: none;
    overflow: hidden;
    z-index: 2147483640;
  `;
  state.lastText;
  for (const misspelling of state.misspellings) {
    const positions = getTextPositions(state.element, misspelling.startIndex, misspelling.endIndex);
    for (const pos of positions) {
      const highlight = document.createElement("div");
      highlight.className = "fsa-misspelling";
      highlight.style.cssText = `
        position: absolute;
        left: ${pos.left - rect.left}px;
        top: ${pos.top - rect.top + pos.height - 2}px;
        width: ${pos.width}px;
        height: 2px;
        pointer-events: auto;
        cursor: pointer;
      `;
      highlight.dataset.word = misspelling.word;
      highlight.dataset.suggestions = JSON.stringify(misspelling.suggestions);
      highlight.setAttribute("role", "button");
      highlight.setAttribute("aria-label", `Misspelled word: ${misspelling.word}. Right-click for suggestions.`);
      highlight.setAttribute("tabindex", "0");
      highlight.addEventListener("contextmenu", handleHighlightContextMenu);
      highlight.addEventListener("click", handleHighlightClick);
      highlight.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          showContextMenu(e.clientX || 0, e.clientY || 0, highlight);
        }
      });
      state.container.appendChild(highlight);
    }
  }
}
function getTextPositions(element, startIndex, endIndex, _fullText) {
  var _a;
  const positions = [];
  if (element.isContentEditable) {
    try {
      const range = document.createRange();
      const textNodes = getTextNodes(element);
      let currentIndex = 0;
      let startNode = null;
      let startOffset = 0;
      let endNode = null;
      let endOffset = 0;
      for (const node of textNodes) {
        const nodeLength = ((_a = node.textContent) == null ? void 0 : _a.length) || 0;
        if (!startNode && currentIndex + nodeLength > startIndex) {
          startNode = node;
          startOffset = startIndex - currentIndex;
        }
        if (currentIndex + nodeLength >= endIndex) {
          endNode = node;
          endOffset = endIndex - currentIndex;
          break;
        }
        currentIndex += nodeLength;
      }
      if (startNode && endNode) {
        range.setStart(startNode, startOffset);
        range.setEnd(endNode, endOffset);
        const rects = range.getClientRects();
        for (let i = 0; i < rects.length; i++) {
          const rect = rects[i];
          positions.push({
            left: rect.left,
            top: rect.top,
            width: rect.width,
            height: rect.height
          });
        }
      }
    } catch {
      const rect = element.getBoundingClientRect();
      positions.push({
        left: rect.left,
        top: rect.top,
        width: 50,
        height: rect.height
      });
    }
  }
  return positions;
}
function getTextNodes(element) {
  const textNodes = [];
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
  let node;
  while (node = walker.nextNode()) {
    textNodes.push(node);
  }
  return textNodes;
}
function updateInputHighlights(state) {
  const element = state.element;
  if (!state.container) {
    state.container = document.createElement("div");
    state.container.className = HIGHLIGHT_CONTAINER_CLASS;
    document.body.appendChild(state.container);
  }
  state.container.innerHTML = "";
  const computedStyle = window.getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  state.container.style.cssText = `
    position: fixed;
    left: ${rect.left}px;
    top: ${rect.top}px;
    width: ${rect.width}px;
    height: ${rect.height}px;
    pointer-events: none;
    overflow: hidden;
    z-index: 2147483640;
  `;
  const mirror = document.createElement("div");
  mirror.className = "fsa-mirror";
  const stylesToCopy = [
    "font-family",
    "font-size",
    "font-weight",
    "font-style",
    "letter-spacing",
    "word-spacing",
    "text-transform",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "border-top-width",
    "border-right-width",
    "border-bottom-width",
    "border-left-width",
    "line-height",
    "text-align"
  ];
  let mirrorStyles = `
    position: absolute;
    left: 0;
    top: 0;
    width: ${element.clientWidth}px;
    visibility: hidden;
    white-space: pre-wrap;
    word-wrap: break-word;
  `;
  for (const prop of stylesToCopy) {
    mirrorStyles += `${prop}: ${computedStyle.getPropertyValue(prop)};`;
  }
  mirror.style.cssText = mirrorStyles;
  document.body.appendChild(mirror);
  const text = element.value;
  const scrollLeft = element.scrollLeft;
  const scrollTop = element.scrollTop;
  for (const misspelling of state.misspellings) {
    const textBefore = text.substring(0, misspelling.startIndex);
    const misspelledWord = text.substring(misspelling.startIndex, misspelling.endIndex);
    mirror.textContent = textBefore;
    const beforeRect = mirror.getBoundingClientRect();
    const span = document.createElement("span");
    span.textContent = misspelledWord;
    mirror.appendChild(span);
    const spanRect = span.getBoundingClientRect();
    const left = spanRect.left - beforeRect.left - scrollLeft;
    const top = beforeRect.height - parseInt(computedStyle.lineHeight) - scrollTop;
    const width = spanRect.width;
    const lineHeight = parseInt(computedStyle.lineHeight) || parseInt(computedStyle.fontSize) * 1.2;
    const highlight = document.createElement("div");
    highlight.className = "fsa-misspelling";
    highlight.style.cssText = `
      position: absolute;
      left: ${Math.max(0, left + parseInt(computedStyle.paddingLeft))}px;
      top: ${Math.max(0, top + lineHeight)}px;
      width: ${width}px;
      height: 2px;
      pointer-events: auto;
      cursor: pointer;
    `;
    highlight.dataset.word = misspelling.word;
    highlight.dataset.suggestions = JSON.stringify(misspelling.suggestions);
    highlight.dataset.start = misspelling.startIndex.toString();
    highlight.dataset.end = misspelling.endIndex.toString();
    highlight.setAttribute("role", "button");
    highlight.setAttribute("aria-label", `Misspelled word: ${misspelling.word}. Right-click for suggestions.`);
    highlight.setAttribute("tabindex", "0");
    highlight.addEventListener("contextmenu", handleHighlightContextMenu);
    highlight.addEventListener("click", handleHighlightClick);
    highlight.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        showContextMenu(e.clientX || 0, e.clientY || 0, highlight);
      }
    });
    state.container.appendChild(highlight);
  }
  mirror.remove();
}
function updateHighlightPositions(state) {
  updateHighlights(state);
}
function handleHighlightContextMenu(event) {
  event.preventDefault();
  event.stopPropagation();
  const target = event.target;
  showContextMenu(event.clientX, event.clientY, target);
}
function handleHighlightClick(event) {
  event.preventDefault();
  event.stopPropagation();
  const target = event.target;
  showContextMenu(event.clientX, event.clientY, target);
}
function showContextMenu(x, y, highlightElement) {
  hideContextMenu();
  const word = highlightElement.dataset.word || "";
  const suggestions = JSON.parse(highlightElement.dataset.suggestions || "[]");
  const menu = document.createElement("div");
  menu.id = CONTEXT_MENU_ID;
  menu.className = "fsa-context-menu";
  menu.setAttribute("role", "menu");
  menu.setAttribute("aria-label", "Spell check suggestions");
  const wordLabel = document.createElement("div");
  wordLabel.className = "fsa-context-menu-word";
  wordLabel.textContent = word;
  menu.appendChild(wordLabel);
  if (suggestions.length > 0) {
    const suggestionsLabel = document.createElement("div");
    suggestionsLabel.className = "fsa-context-menu-label";
    suggestionsLabel.textContent = "Suggestions";
    menu.appendChild(suggestionsLabel);
    for (const suggestion of suggestions.slice(0, 5)) {
      const item = document.createElement("div");
      item.className = "fsa-context-menu-item fsa-context-menu-suggestion";
      item.textContent = suggestion;
      item.setAttribute("role", "menuitem");
      item.setAttribute("tabindex", "0");
      item.setAttribute("aria-label", `Replace with ${suggestion}`);
      item.addEventListener("click", () => {
        applySuggestion(highlightElement, suggestion);
        hideContextMenu();
      });
      item.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          applySuggestion(highlightElement, suggestion);
          hideContextMenu();
        }
      });
      menu.appendChild(item);
    }
  } else {
    const emptyItem = document.createElement("div");
    emptyItem.className = "fsa-context-menu-empty";
    emptyItem.textContent = "No suggestions";
    menu.appendChild(emptyItem);
  }
  const divider = document.createElement("div");
  divider.className = "fsa-context-menu-divider";
  menu.appendChild(divider);
  const ignoreItem = document.createElement("div");
  ignoreItem.className = "fsa-context-menu-item fsa-context-menu-action";
  ignoreItem.innerHTML = `<span class="fsa-context-menu-icon">🚫</span> Ignore`;
  ignoreItem.setAttribute("role", "menuitem");
  ignoreItem.setAttribute("tabindex", "0");
  ignoreItem.setAttribute("aria-label", "Ignore this word for this session");
  ignoreItem.addEventListener("click", () => {
    ignoreWord(word);
    hideContextMenu();
  });
  ignoreItem.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      ignoreWord(word);
      hideContextMenu();
    }
  });
  menu.appendChild(ignoreItem);
  const addItem = document.createElement("div");
  addItem.className = "fsa-context-menu-item fsa-context-menu-action";
  addItem.innerHTML = `<span class="fsa-context-menu-icon">📖</span> Add to Dictionary`;
  addItem.setAttribute("role", "menuitem");
  addItem.setAttribute("tabindex", "0");
  addItem.setAttribute("aria-label", `Add ${word} to custom dictionary`);
  addItem.addEventListener("click", () => {
    addWordToDictionary(word);
    hideContextMenu();
  });
  addItem.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      addWordToDictionary(word);
      hideContextMenu();
    }
  });
  menu.appendChild(addItem);
  document.body.appendChild(menu);
  const menuRect = menu.getBoundingClientRect();
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const padding = 10;
  let menuX = x;
  let menuY = y;
  if (x + menuRect.width + padding > viewportWidth) {
    menuX = Math.max(padding, x - menuRect.width - padding);
    if (menuX + menuRect.width > viewportWidth) {
      menuX = viewportWidth - menuRect.width - padding;
    }
  } else {
    menuX = x + padding;
  }
  if (y + menuRect.height + padding > viewportHeight) {
    menuY = Math.max(padding, y - menuRect.height - padding);
    if (menuY + menuRect.height > viewportHeight) {
      menuY = viewportHeight - menuRect.height - padding;
    }
  } else {
    menuY = y + padding;
  }
  menu.style.left = `${menuX}px`;
  menu.style.top = `${menuY}px`;
  activeContextMenu = menu;
  setTimeout(() => {
    document.addEventListener("click", handleDocumentClick);
    document.addEventListener("keydown", handleDocumentKeydown);
  }, 0);
}
function hideContextMenu() {
  if (activeContextMenu) {
    activeContextMenu.remove();
    activeContextMenu = null;
  }
  document.removeEventListener("click", handleDocumentClick);
  document.removeEventListener("keydown", handleDocumentKeydown);
}
function handleDocumentClick(event) {
  if (activeContextMenu && !activeContextMenu.contains(event.target)) {
    hideContextMenu();
  }
}
function handleDocumentKeydown(event) {
  if (event.key === "Escape") {
    hideContextMenu();
  }
}
async function applySuggestion(highlightElement, suggestion) {
  const container = highlightElement.parentElement;
  if (!container) return;
  for (const [element, state] of fieldStates) {
    if (state.container === container) {
      const word = highlightElement.dataset.word || "";
      const startStr = highlightElement.dataset.start;
      const endStr = highlightElement.dataset.end;
      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
        if (startStr && endStr) {
          const start = parseInt(startStr);
          const end = parseInt(endStr);
          const text = element.value;
          element.value = text.substring(0, start) + suggestion + text.substring(end);
          const newCursorPos = start + suggestion.length;
          element.setSelectionRange(newCursorPos, newCursorPos);
          element.dispatchEvent(new Event("input", { bubbles: true }));
          showToast(`Replaced "${word}" with "${suggestion}"`, "success", 2e3);
        }
      } else if (element.isContentEditable) {
        const html = element.innerHTML;
        const newHtml = html.replace(new RegExp(`\\b${escapeRegExp(word)}\\b`), suggestion);
        element.innerHTML = newHtml;
        element.dispatchEvent(new Event("input", { bubbles: true }));
      }
      incrementCorrectionsMade(1).catch(() => {
      });
      scheduleSpellCheck(state);
      break;
    }
  }
}
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function ignoreWord(word) {
  ignoredWords.add(word.toLowerCase());
  for (const state of fieldStates.values()) {
    performSpellCheck(state);
  }
}
async function addWordToDictionary(word) {
  try {
    await chrome.runtime.sendMessage({ type: "ADD_TO_DICTIONARY", word });
    customDictionaryWords.add(word.toLowerCase());
    incrementWordsAdded(1).catch(() => {
    });
    showToast(`Added "${word}" to dictionary`, "success");
    for (const state of fieldStates.values()) {
      performSpellCheck(state);
    }
  } catch (error) {
    console.error("FSA: Error adding to dictionary:", error);
    showToast("Failed to add word to dictionary", "error");
  }
}
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node instanceof HTMLElement) {
          if (isEditableField(node)) {
            attachToField(node);
          }
          const editables = node.querySelectorAll('input, textarea, [contenteditable="true"]');
          editables.forEach((el) => {
            if (el instanceof HTMLElement && isEditableField(el)) {
              attachToField(el);
            }
          });
        }
      }
      for (const node of mutation.removedNodes) {
        if (node instanceof HTMLElement) {
          if (fieldStates.has(node)) {
            detachFromField(node);
          }
          const editables = node.querySelectorAll('input, textarea, [contenteditable="true"]');
          editables.forEach((el) => {
            if (el instanceof HTMLElement && fieldStates.has(el)) {
              detachFromField(el);
            }
          });
        }
      }
      if (mutation.type === "attributes" && mutation.target instanceof HTMLElement) {
        const el = mutation.target;
        if (mutation.attributeName === "contenteditable") {
          if (el.isContentEditable && isEditableField(el)) {
            attachToField(el);
          } else {
            detachFromField(el);
          }
        }
      }
    }
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["contenteditable"]
  });
}
function setupEventListeners() {
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "SETTINGS_CHANGED") {
      if (message.globalSettings) {
        globalSettings = message.globalSettings;
      }
      if (message.siteSettings) {
        siteSettings = message.siteSettings;
      }
      if (isEnabled()) {
        for (const state of fieldStates.values()) {
          performSpellCheck(state);
        }
      } else {
        for (const state of fieldStates.values()) {
          clearHighlights(state);
        }
      }
    }
    if (message.type === "DICTIONARY_CHANGED") {
      loadCustomDictionary().then(() => {
        for (const state of fieldStates.values()) {
          performSpellCheck(state);
        }
      });
    }
  });
  window.addEventListener("resize", () => {
    for (const state of fieldStates.values()) {
      if (state.container) {
        updateHighlights(state);
      }
    }
  });
  window.addEventListener("scroll", () => {
    for (const state of fieldStates.values()) {
      if (state.container) {
        updateHighlights(state);
      }
    }
  }, true);
}
console.log("FSA: Content script file loaded");
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    console.log("FSA: DOMContentLoaded fired");
    initialize().catch((error) => {
      console.error("FSA: Initialization failed:", error);
    });
  });
} else {
  console.log("FSA: DOM already ready, initializing immediately");
  initialize().catch((error) => {
    console.error("FSA: Initialization failed:", error);
  });
}
//# sourceMappingURL=content.js.map

const STORAGE_KEYS = {
  GLOBAL_SETTINGS: "globalSettings",
  SITE_SETTINGS_PREFIX: "site:",
  CUSTOM_DICTIONARY: "customDictionary",
  STATISTICS: "statistics"
};
const DEFAULT_STATISTICS = {
  wordsChecked: 0,
  misspellingsFound: 0,
  correctionsMade: 0,
  wordsAdded: 0,
  lastReset: Date.now()
};
const DEFAULT_GLOBAL_SETTINGS = {
  enabled: true,
  showUnderlines: true,
  language: "en-US",
  disabledPatterns: [],
  autoCorrect: false,
  grammarCheck: false
};
const DEFAULT_SITE_SETTINGS = {
  enabled: true
};
async function getGlobalSettings() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.GLOBAL_SETTINGS);
  return { ...DEFAULT_GLOBAL_SETTINGS, ...result[STORAGE_KEYS.GLOBAL_SETTINGS] };
}
async function setGlobalSettings(settings) {
  const current = await getGlobalSettings();
  const updated = { ...current, ...settings };
  await chrome.storage.sync.set({ [STORAGE_KEYS.GLOBAL_SETTINGS]: updated });
  return updated;
}
async function getSiteSettings(hostname) {
  const key = `${STORAGE_KEYS.SITE_SETTINGS_PREFIX}${hostname}`;
  const result = await chrome.storage.sync.get(key);
  return { ...DEFAULT_SITE_SETTINGS, ...result[key] };
}
async function setSiteSettings(hostname, settings) {
  const key = `${STORAGE_KEYS.SITE_SETTINGS_PREFIX}${hostname}`;
  const current = await getSiteSettings(hostname);
  const updated = { ...current, ...settings };
  await chrome.storage.sync.set({ [key]: updated });
  return updated;
}
async function getCustomDictionary() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.CUSTOM_DICTIONARY);
  return result[STORAGE_KEYS.CUSTOM_DICTIONARY] || [];
}
async function addToDictionary(word) {
  const normalizedWord = word.toLowerCase().trim();
  if (!normalizedWord) return false;
  const entries = await getCustomDictionary();
  if (entries.some((e) => e.word.toLowerCase() === normalizedWord)) {
    return false;
  }
  const newEntry = {
    word: normalizedWord,
    addedAt: Date.now()
  };
  entries.push(newEntry);
  await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: entries });
  return true;
}
async function removeFromDictionary(word) {
  const normalizedWord = word.toLowerCase().trim();
  const entries = await getCustomDictionary();
  const filtered = entries.filter((e) => e.word.toLowerCase() !== normalizedWord);
  if (filtered.length === entries.length) {
    return false;
  }
  await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: filtered });
  return true;
}
async function importDictionary(words) {
  const entries = await getCustomDictionary();
  const existingWords = new Set(entries.map((e) => e.word.toLowerCase()));
  let addedCount = 0;
  const now = Date.now();
  for (const word of words) {
    const normalized = word.toLowerCase().trim();
    if (normalized && !existingWords.has(normalized)) {
      entries.push({ word: normalized, addedAt: now });
      existingWords.add(normalized);
      addedCount++;
    }
  }
  if (addedCount > 0) {
    await chrome.storage.sync.set({ [STORAGE_KEYS.CUSTOM_DICTIONARY]: entries });
  }
  return addedCount;
}
async function exportDictionary() {
  const entries = await getCustomDictionary();
  return entries.map((e) => e.word);
}
async function getStatistics() {
  const result = await chrome.storage.sync.get(STORAGE_KEYS.STATISTICS);
  return { ...DEFAULT_STATISTICS, ...result[STORAGE_KEYS.STATISTICS] };
}
async function updateStatistics(updates) {
  const current = await getStatistics();
  const updated = { ...current, ...updates };
  await chrome.storage.sync.set({ [STORAGE_KEYS.STATISTICS]: updated });
  return updated;
}
const storage = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addToDictionary,
  exportDictionary,
  getCustomDictionary,
  getGlobalSettings,
  getSiteSettings,
  getStatistics,
  importDictionary,
  removeFromDictionary,
  setGlobalSettings,
  setSiteSettings,
  updateStatistics
}, Symbol.toStringTag, { value: "Module" }));
export {
  DEFAULT_STATISTICS as D,
  STORAGE_KEYS as S,
  getCustomDictionary as a,
  addToDictionary as b,
  getSiteSettings as c,
  setGlobalSettings as d,
  exportDictionary as e,
  getGlobalSettings as f,
  getStatistics as g,
  DEFAULT_GLOBAL_SETTINGS as h,
  importDictionary as i,
  DEFAULT_SITE_SETTINGS as j,
  storage as k,
  removeFromDictionary as r,
  setSiteSettings as s,
  updateStatistics as u
};
//# sourceMappingURL=storage-BuTDZeqy.js.map
