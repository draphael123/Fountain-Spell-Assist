import { r as reactExports, s as setSiteSettings, a as setGlobalSettings, j as jsxRuntimeExports, g as getCurrentTabHostname, b as getGlobalSettings, c as getStatistics, d as getSiteSettings, e as createRoot, R as React } from "./messaging-BeVb5Fph.js";
function Popup() {
  const [loading, setLoading] = reactExports.useState(true);
  const [hostname, setHostname] = reactExports.useState("");
  const [globalSettings, setGlobalSettingsState] = reactExports.useState(null);
  const [siteSettings, setSiteSettingsState] = reactExports.useState(null);
  const [statistics, setStatistics] = reactExports.useState(null);
  reactExports.useEffect(() => {
    async function load() {
      try {
        const [host, global, site, stats] = await Promise.all([
          getCurrentTabHostname().catch(() => ""),
          getGlobalSettings(),
          getCurrentTabHostname().then((h) => getSiteSettings(h)).catch(() => ({ enabled: true })),
          getStatistics().catch(() => null)
        ]);
        setHostname(host);
        setGlobalSettingsState(global);
        setSiteSettingsState(site);
        setStatistics(stats);
      } catch (error) {
        console.error("Failed to load settings:", error);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);
  const handleSiteToggle = reactExports.useCallback(async () => {
    if (!siteSettings || !hostname) return;
    const newEnabled = !siteSettings.enabled;
    setSiteSettingsState({ ...siteSettings, enabled: newEnabled });
    try {
      await setSiteSettings(hostname, { enabled: newEnabled });
    } catch (error) {
      console.error("Failed to update site settings:", error);
      setSiteSettingsState(siteSettings);
    }
  }, [siteSettings, hostname]);
  const handleUnderlinesToggle = reactExports.useCallback(async () => {
    if (!globalSettings) return;
    const newShowUnderlines = !globalSettings.showUnderlines;
    setGlobalSettingsState({ ...globalSettings, showUnderlines: newShowUnderlines });
    try {
      await setGlobalSettings({ showUnderlines: newShowUnderlines });
    } catch (error) {
      console.error("Failed to update global settings:", error);
      setGlobalSettingsState(globalSettings);
    }
  }, [globalSettings]);
  const openOptions = reactExports.useCallback(() => {
    chrome.runtime.openOptionsPage();
  }, []);
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "loading", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "loading-spinner" }) });
  }
  const isActive = (globalSettings == null ? void 0 : globalSettings.enabled) && (siteSettings == null ? void 0 : siteSettings.enabled);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "popup", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "popup-header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "popup-logo", children: "🖋" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "popup-title", children: "Fountain" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "popup-subtitle", children: "Spell Assist" })
      ] })
    ] }),
    hostname && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "site-info", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "site-label", children: "Current Site" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "site-hostname", children: hostname })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toggle-section", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toggle-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toggle-info", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "toggle-label", children: (siteSettings == null ? void 0 : siteSettings.enabled) ? "Enabled" : "Disabled" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "toggle-description", children: "Spell check on this site" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: `toggle-switch ${(siteSettings == null ? void 0 : siteSettings.enabled) ? "active" : ""}`,
            onClick: handleSiteToggle,
            "aria-label": "Toggle spell check for this site"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toggle-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toggle-info", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "toggle-label", children: "Underlines" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "toggle-description", children: "Show misspelling highlights" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: `toggle-switch ${(globalSettings == null ? void 0 : globalSettings.showUnderlines) ? "active" : ""}`,
            onClick: handleUnderlinesToggle,
            "aria-label": "Toggle underline display"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `status-indicator ${isActive ? "" : "disabled"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "status-dot" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "status-text", children: isActive ? "Spell checking active" : "Spell checking paused" })
    ] }),
    statistics && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "statistics-section", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "statistics-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-value", children: statistics.wordsChecked.toLocaleString() }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-label", children: "Words Checked" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-value", children: statistics.misspellingsFound.toLocaleString() }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-label", children: "Misspellings Found" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-value", children: statistics.correctionsMade.toLocaleString() }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-label", children: "Corrections Made" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "popup-footer", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "options-link", onClick: openOptions, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "12", cy: "12", r: "3" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" })
      ] }),
      "Options"
    ] }) })
  ] });
}
const container = document.getElementById("root");
if (container) {
  const root = createRoot(container);
  root.render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}) })
  );
}
//# sourceMappingURL=popup-CRlQKpWA.js.map
