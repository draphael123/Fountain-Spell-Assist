import { u as updateStatistics, D as DEFAULT_STATISTICS, g as getStatistics, e as exportDictionary, i as importDictionary, a as getCustomDictionary, r as removeFromDictionary, b as addToDictionary, s as setSiteSettings, c as getSiteSettings, d as setGlobalSettings, f as getGlobalSettings } from "./assets/storage-BuTDZeqy.js";
async function handleMessage(message, _sender) {
  try {
    switch (message.type) {
      case "GET_GLOBAL_SETTINGS": {
        const settings = await getGlobalSettings();
        return { success: true, data: settings };
      }
      case "SET_GLOBAL_SETTINGS": {
        const settings = await setGlobalSettings(message.settings);
        broadcastSettingsChange({ globalSettings: settings });
        return { success: true, data: settings };
      }
      case "GET_SITE_SETTINGS": {
        const settings = await getSiteSettings(message.hostname);
        return { success: true, data: settings };
      }
      case "SET_SITE_SETTINGS": {
        const settings = await setSiteSettings(message.hostname, message.settings);
        broadcastSettingsChange({ siteSettings: settings }, message.hostname);
        return { success: true, data: settings };
      }
      case "ADD_TO_DICTIONARY": {
        const added = await addToDictionary(message.word);
        broadcastDictionaryChange();
        return { success: true, data: added };
      }
      case "REMOVE_FROM_DICTIONARY": {
        const removed = await removeFromDictionary(message.word);
        broadcastDictionaryChange();
        return { success: true, data: removed };
      }
      case "GET_DICTIONARY": {
        const entries = await getCustomDictionary();
        return { success: true, data: entries };
      }
      case "IMPORT_DICTIONARY": {
        const addedCount = await importDictionary(message.words);
        broadcastDictionaryChange();
        return { success: true, data: addedCount };
      }
      case "EXPORT_DICTIONARY": {
        const words = await exportDictionary();
        return { success: true, data: words };
      }
      case "GET_STATISTICS": {
        const stats = await getStatistics();
        return { success: true, data: stats };
      }
      case "RESET_STATISTICS": {
        const stats = await updateStatistics({ ...DEFAULT_STATISTICS, lastReset: Date.now() });
        return { success: true, data: stats };
      }
      default:
        return { success: false, error: "Unknown message type" };
    }
  } catch (error) {
    console.error("FSA: Error handling message:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
}
async function broadcastSettingsChange(data, hostname) {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.id || !tab.url) continue;
    if (hostname) {
      try {
        const url = new URL(tab.url);
        if (url.hostname !== hostname) continue;
      } catch {
        continue;
      }
    }
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "SETTINGS_CHANGED",
        ...data
      });
    } catch {
    }
  }
}
async function broadcastDictionaryChange() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.id) continue;
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "DICTIONARY_CHANGED"
      });
    } catch {
    }
  }
}
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    handleMessage(message).then(sendResponse);
    return true;
  }
);
console.log("Fountain Spell Assist: Service worker initialized");
//# sourceMappingURL=background.js.map
